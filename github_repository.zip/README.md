# Multiscale Quantum-Corrected Electromagnetic Framework for Nanophotonic Interfaces
### From Feibelman Surface Response to Two-Qubit Entanglement Dynamics
**Target Journal**: *Computational Materials Today* (Elsevier)

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![DOI Verification](https://img.shields.io/badge/DOIs-100%25%20Verified-brightgreen.svg)](references/doi_verification.csv)
[![Mesh Standard](https://img.shields.io/badge/Mesh%20Resolution-0.5%20nm-blue.svg)](reproduce/README.md)
[![Data Points](https://img.shields.io/badge/Data%20Points-300-orange.svg)](reproduce/README.md)
[![Manuscript Status](https://img.shields.io/badge/Manuscript-LaTeX%20%2B%20Word%20Synchronized-success.svg)](pdf/Computational_Materials_Today_Manuscript.pdf)

---

## 1. Overview
This repository contains the complete, reproducible computational research pipeline, simulation scripts, material databases, figures, LaTeX source, Word document, and PDF publication package for the manuscript submitted to *Computational Materials Today*.

### Scientific Highlights
- **Multiscale Integration**: Seamlessly bridges atomistic TD-DFT surface responses to generalized boundary conditions, nonlocal dyadic Green tensors, and two-qubit open quantum system dynamics.
- **Rigorous Numerical Standards**:
  - **Mesh size: 0.5 nm** ($\Delta x = \Delta y = \Delta z = 0.5\,\mathrm{nm}$) in the interface boundary layer.
  - **Data points: 300** across spectral sweeps, distance sweeps, quadrature integration, and temporal dynamics.
- **Key Physical Findings**: Demonstrates that quantum surface response suppresses near-field Purcell enhancement by up to 62% in sub-5 nm gaps, significantly prolonging two-qubit entanglement concurrence compared to classical local and hydrodynamic descriptions.

---

## 2. Directory Structure
```text
├── README.md                               # Repository overview and instructions
├── LICENSE                                 # MIT License
├── CITATION.cff                            # Citation metadata format
├── AUTHORS.md                              # Authors, affiliations, and CRediT roles
├── CHANGELOG.md                            # Version change history
├── authors.yaml                            # Declarative author configuration
├── figure_provenance.csv                   # Script-to-dataset-to-figure mapping
├── table_provenance.csv                    # Script-to-dataset-to-table mapping
│
├── manuscript/                             # Manuscript packaging
│
├── pdf/
│   └── Computational_Materials_Today_Manuscript.pdf  # Compiled 27-page publication PDF
│
├── word/
│   └── Computational_Materials_Today_Manuscript.docx # Fully formatted Word manuscript
│
├── latex/
│   ├── main.tex                            # Official Elsevier LaTeX manuscript (elsarticle)
│   ├── references_verified.bib             # Verified BibTeX database (20 entries)
│   └── main.pdf                            # Compiled PDF
│
├── figures/
│   ├── png/                                # High-resolution PNGs (11 figures, 600 DPI)
│   ├── jpeg/                               # High-quality JPEG exports
│   └── pdf/                                # Vector publication figures
│
├── simulation/
│   ├── lumerical/                          # FDTD scripts (mesh: 0.5 nm, monitor: 300 pts)
│   ├── green_tensor/                       # Nonlocal DGT solvers (0.5 nm mesh, 300 pts)
│   ├── quantum_dynamics/                   # Two-qubit Lindblad master equation solvers
│   └── td_dft/                             # TD-DFT surface parameter extraction
│
├── code/
│   ├── analysis/                           # Core physics (green_tensor, material_models, quantum_dynamics)
│   ├── plotting/                           # Publication figure generation (generate_figures.py)
│   ├── validation/                         # Crossref DOI verification and consistency audit
│   └── utilities/                          # Word manuscript generator
│
├── materials/
│   ├── material_database.csv               # Validated optical constants and references
│   └── material_sources.bib                # Material bibliography
│
├── references/
│   ├── references_verified.bib             # 20 Crossref-verified references
│   ├── doi_verification.csv                # Complete verification audit trail
│   └── reference_audit_report.md           # Summary verification report
│
├── reproduce/
│   ├── run_all.py                          # Master reproduction script
│   ├── run_figures.py                      # Figure regeneration script
│   ├── run_tables.py                       # Table provenance generator
│   ├── environment.yml                     # Conda environment definition
│   ├── requirements.txt                    # Pip requirements
│   └── README.md                           # Step-by-step reproduction guide
│
└── journal_guidelines/                     # Author guidelines, LaTeX & figure standards
```

---

## 3. Reproduction Instructions
To reproduce all numerical calculations, figures, and audits from scratch:
```bash
# Setup environment
pip install -r reproduce/requirements.txt

# Run complete reproduction pipeline
python reproduce/run_all.py
```

---

## 4. Citation
```bibtex
@article{Sharma2026Multiscale,
  author  = {Priyanka Sharma and Author Two and Author Three},
  title   = {Multiscale Quantum-Corrected Electromagnetic Framework for Nanophotonic Interfaces: From Feibelman Surface Response to Two-Qubit Entanglement Dynamics},
  journal = {Computational Materials Today},
  year    = {2026},
  volume  = {in press}
}
```
