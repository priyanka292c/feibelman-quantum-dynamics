# Research Direction Decision
**Date: 2026-10-21**

## Decision: **Option B — Feibelman–TD-DFT–Dyadic Green Tensor Quantum-Materials Framework**

---

## Evaluation Matrix

| Criterion | Option A (Chiral Optomechanics) | Option B (Feibelman/Green Tensor) | Option C (Unified) |
|---|---|---|---|
| CMT Scope fit | Good (optical/plasmonic) | Excellent (quantum/optical/method) | Moderate (risks diffusion) |
| Computational method novelty | Moderate (FDTD + MST well-established) | High (multiscale quantum-to-classical) | Low (would be superficial in both) |
| Material novelty | Moderate (Sb2S3/Au known) | High (quantum corrections to Au/Cu interfaces) | Mixed |
| Theoretical novelty | Low–Moderate | High (Feibelman GBC + nonlocal DGT) | Mixed |
| Reproducibility (no Lumerical license confirmed) | Low (relies on FDTD runs) | High (Python-implementable) | Mixed |
| Validated material parameters available | Yes | Yes (literature d-params) | Yes |
| Computational feasibility (Python only) | Low | High | Low |
| Quantitative results possible | Yes (with license) | Yes (without proprietary software) | Partial |
| Literature comparison available | Many (crowded field) | Fewer, clearer gap | Mixed |
| Scientific significance | Good | Excellent | Diluted |
| Publication figure quality | Good | Excellent | Mixed |
| Journal fit (CMT) | Good | Excellent | Moderate |

---

## Selected Direction: **Option B**

### Scientific Rationale
1. **Methodological novelty**: The integration of TD-DFT-derived Feibelman surface-response functions *d*⊥(ω) and *d*∥(ω) with a numerically implemented nonlocal dyadic Green tensor (DGT) framework represents a genuine methodological advance. Classical local, hydrodynamic, and Feibelman-corrected descriptions predict quantitatively different LDOS, Purcell factors, and quantum-emitter decay rates for nanometer-scale gaps.

2. **Computational feasibility without proprietary FDTD license**: The entire computational pipeline — from Feibelman parameter interpolation to Green tensor computation, LDOS calculation, Purcell enhancement, and two-qubit quantum dynamics — can be implemented in Python (NumPy/SciPy/QuTiP) using validated literature parameters. This ensures reproducibility.

3. **Materials novelty**: The Au/Cu bimetallic interface has not been exhaustively studied in the Feibelman-corrected Green tensor context. Copper introduces d-band screening effects distinct from gold, and the quantum surface response differs measurably.

4. **Theoretical depth**: The Lindblad/HEOM two-qubit dynamics calculation, driven by Feibelman-corrected Green tensor coupling, represents a complete atomistic-to-quantum-dynamics pipeline rarely implemented in a single computational study.

5. **CMT scope**: The journal explicitly covers quantum materials, nanomaterials, and computational method development. This study advances a computational framework, validated against multiple model hierarchies.

---

## Rejected Alternative: Option A
- Heavily relies on active Lumerical FDTD license for core results (optical force via MST requires FDTD fields)
- Chiral plasmonic optomechanics with phase-change materials is a rapidly growing but increasingly crowded subfield
- Difficult to generate quantitative novel results without full FDTD computation

## Rejected Alternative: Option C
- Combining two research directions without sufficient computational resources for FDTD would produce superficial treatment of Direction A
- A unified paper risks insufficient depth in either direction

---

## Novelty Statement
This work presents a **physically transparent, multiscale computational framework** that:
1. Imports TD-DFT-derived Feibelman surface-response parameters *d*⊥(ω) and *d*∥(ω) from the published literature
2. Incorporates them as generalized boundary conditions into a numerically computed nonlocal dyadic Green tensor
3. Quantifies LDOS and Purcell factor corrections beyond local Drude and hydrodynamic descriptions
4. Propagates the quantum-corrected electromagnetic environment into two-qubit open quantum system dynamics
5. Evaluates entanglement generation (concurrence) as a function of emitter separation and quantum surface-response magnitude

---

## Testable Hypothesis
*A physically consistent multiscale computational framework incorporating quantum surface-response effects (Feibelman d-parameters) quantitatively modifies the predicted electromagnetic local density of states, Purcell enhancement, and two-qubit entanglement dynamics in sub-10-nm metal–vacuum interfaces beyond the predictions of both local and nonlocal hydrodynamic descriptions.*

---

## Computational Objectives
1. Implement local, hydrodynamic, and Feibelman-corrected dyadic Green tensor models
2. Compute LDOS as a function of emitter–surface distance (z = 1–20 nm)
3. Compute Purcell factor for Au and Au/Cu interfaces
4. Quantify resonance wavelength shift and linewidth change across three models
5. Propagate Green tensor results into Lindblad master equation for two-qubit system
6. Calculate concurrence evolution versus inter-qubit coupling and surface-response strength
7. Perform sensitivity analysis: mesh, material parameters, d-parameter uncertainty
8. Validate against published benchmarks

---

## Expected Contribution
A complete, Python-reproducible computational pipeline from quantum surface response to quantum entanglement dynamics, with quantitative demonstration of when and why classical local/hydrodynamic models fail for nanometric quantum-plasmonic systems.
