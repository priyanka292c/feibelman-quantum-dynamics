# Changelog

All notable changes to this research repository are documented herein.

## [1.0.0] - 2026-10-21
### Added
- Complete multiscale Feibelman surface-response to two-qubit entanglement dynamics framework.
- Spatial mesh override standard: 0.5 nm resolution at metal-vacuum interface.
- 300 data points across spectral, distance, temporal, and quadrature evaluations.
- Full suite of 11 publication-quality figures generated in PNG (600 DPI), JPEG, and PDF.
- 20 verified references cross-checked and confirmed via Crossref API.
- Complete 27-page LaTeX manuscript compiled cleanly using `elsarticle.cls`.
- Word manuscript (`.docx`) with identical figures, equations, tables, and declarations.
- Automated reproduction suite and consistency audit engine.
