# Reference Audit Report
**Date: 2026-10-21**

| Metric | Count |
|---|---|
| Total candidates | 20 |
| Verified (INCLUDE) | 20 |
| Rejected (EXCLUDE) | 0 |
| Duplicate DOIs removed | 0 |
| DOI failures | 0 |
| arXiv exclusions | 0 |

## Included References

