# Authors and Contributors

## Primary Authors
- **Priyanka Sharma** (Corresponding Author)
  - Department of Physics and Materials Science, Institution One, City, Country
  - Email: `corresponding.author@institution.edu`
  - CRediT roles: Conceptualization, Methodology, Software, Formal analysis, Investigation, Writing – Original Draft, Visualization.
- **Author Two**
  - Department of Physics and Materials Science, Institution One, City, Country
  - CRediT roles: Software, Validation, Data curation, Writing – Review & Editing.
- **Author Three**
  - Department of Computational Science, Institution Two, City, Country
  - CRediT roles: Supervision, Project administration, Resources, Funding acquisition.
