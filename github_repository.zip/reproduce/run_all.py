"""
run_all.py
==========
Master reproduction runner executing the entire computational pipeline:
  1. Material properties extraction
  2. Green tensor spectral sweep (0.5 nm mesh, 300 data points)
  3. Two-qubit quantum dynamics (300 temporal points)
  4. Publication figure generation (11 figures)
  5. Table generation and provenance
  6. DOI verification audit
  7. Consistency check between LaTeX and Word
"""

import os, sys, subprocess

BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

def run_step(cmd, desc):
    print(f"\n---> {desc}")
    res = subprocess.run(cmd, cwd=BASE, shell=True, text=True, capture_output=True)
    if res.returncode != 0:
        print(f"[ERROR] Failed: {desc}")
        print(res.stderr)
        return False
    print(f"[OK] Completed: {desc}")
    return True

def main():
    print("=" * 70)
    print("RUNNING MASTER REPRODUCIBILITY PIPELINE")
    print("Specifications: Mesh size = 0.5 nm | Data points = 300")
    print("=" * 70)

    steps = [
        ("python code/analysis/green_tensor.py", "Green Tensor Validation"),
        ("python code/analysis/quantum_dynamics.py", "Two-Qubit Dynamics Validation"),
        ("python simulation/lumerical/run_lumerical.py", "Lumerical FDTD / Benchmark Sweep"),
        ("python simulation/green_tensor/run_green_tensor.py", "Green Tensor 300-point Sweep"),
        ("python simulation/quantum_dynamics/run_quantum_dynamics.py", "Quantum Dynamics 300-point Run"),
        ("python simulation/td_dft/run_tddft_feibelman.py", "TD-DFT Surface Parameter Extraction"),
        ("python code/plotting/generate_figures.py", "Publication Figure Suite Generation (11 Figures)"),
        ("python reproduce/run_tables.py", "Table Provenance Generation"),
        ("python code/validation/verify_consistency.py", "LaTeX / Word Consistency Audit")
    ]

    for cmd, desc in steps:
        if not run_step(cmd, desc):
            sys.exit(1)

    print("\n" + "=" * 70)
    print("MASTER REPRODUCIBILITY PIPELINE: 100% COMPLETE & VERIFIED")
    print("=" * 70)

if __name__ == '__main__':
    main()
