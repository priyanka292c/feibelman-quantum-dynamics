# Reproduction Guide
**Manuscript: Multiscale Quantum-Corrected Electromagnetic Framework for Nanophotonic Interfaces**
Target Journal: *Computational Materials Today* (Elsevier)

## Numerical Specifications
- **Spatial mesh resolution**: 0.5 nm ($\Delta x = \Delta y = \Delta z = 0.5\,\mathrm{nm}$) in the interface boundary layer
- **Data points**: 300 points across spectral, distance, temporal, and quadrature evaluations

## Environment Setup
```bash
conda env create -f environment.yml
conda activate feibelman-qed
# or
pip install -r requirements.txt
```

## Reproduction Commands
1. Run entire pipeline:
```bash
python reproduce/run_all.py
```
2. Reproduce all 11 figures:
```bash
python reproduce/run_figures.py
```
3. Reproduce tables and provenance:
```bash
python reproduce/run_tables.py
```
4. Verify LaTeX / Word consistency:
```bash
python code/validation/verify_consistency.py
```
