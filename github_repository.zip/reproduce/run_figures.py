"""
run_figures.py
==============
Reproduces all 11 publication figures with 0.5 nm mesh size and 300 data points.
"""

import sys, os
BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(BASE, 'code', 'plotting'))
import generate_figures

if __name__ == '__main__':
    print("Reproducing all 11 manuscript figures...")
    generate_figures.figure1_framework_architecture()
    generate_figures.figure2_material_properties()
    generate_figures.figure3_geometry_setup()
    generate_figures.figure4_convergence()
    generate_figures.figure5_ldos_spectra()
    generate_figures.figure6_purcell_vs_distance()
    generate_figures.figure7_parameter_map()
    generate_figures.figure8_au_vs_cu()
    generate_figures.figure9_model_comparison()
    generate_figures.figure10_sensitivity()
    generate_figures.figure11_quantum_dynamics()
    print("All figures reproduced successfully.")
