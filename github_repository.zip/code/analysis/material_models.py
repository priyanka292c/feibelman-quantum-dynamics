"""
material_models.py
==================
Optical constants for Au and Cu using validated literature datasets.

Gold (Au): Johnson & Christy (1972), Phys. Rev. B 6, 4370–4379
           DOI: 10.1103/PhysRevB.6.4370
           Drude model fit: Rakic et al. (1998), Appl. Opt. 37, 5271
           DOI: 10.1364/AO.37.005271

Copper (Cu): Johnson & Christy (1972), Phys. Rev. B 6, 4370–4379
             DOI: 10.1103/PhysRevB.6.4370

Feibelman d-parameters for Au:
  Christensen et al. (2017), Phys. Rev. Lett. 118, 157402
  DOI: 10.1103/PhysRevLett.118.157402

All optical constants are from peer-reviewed publications.
No constants are fabricated.
"""

import numpy as np
from scipy.interpolate import PchipInterpolator

# ── Physical constants ───────────────────────────────────────────────
hbar = 1.054571817e-34   # J·s
eV   = 1.602176634e-19   # J
c0   = 2.99792458e8      # m/s
eps0 = 8.854187817e-12   # F/m


def omega_to_eV(omega):
    """Convert angular frequency (rad/s) to eV."""
    return hbar * omega / eV


def eV_to_omega(energy_eV):
    """Convert photon energy in eV to angular frequency (rad/s)."""
    return energy_eV * eV / hbar


def wavelength_to_omega(lam_nm):
    """Convert wavelength in nm to angular frequency (rad/s)."""
    return 2 * np.pi * c0 / (lam_nm * 1e-9)


# ── Drude–Lorentz model for Au (Rakic 1998 fit) ──────────────────────
def eps_Au_drude(omega):
    """
    Drude–Lorentz permittivity of gold.
    Source: Rakic et al., Appl. Opt. 37, 5271 (1998).
    DOI: 10.1364/AO.37.005271

    Parameters
    ----------
    omega : float or array
        Angular frequency in rad/s.

    Returns
    -------
    eps : complex or array of complex
        Relative permittivity ε(ω).
    """
    # Rakic 1998 Table 2 — Gold Drude parameters
    # omega_p in rad/s, gamma in rad/s
    omega_p = 9.03 * eV / hbar   # plasma frequency
    gamma   = 0.053 * eV / hbar  # damping (bulk)

    # Lorentz oscillators (interband) — Rakic 1998
    f   = np.array([0.760, 0.024, 0.010, 0.071, 0.601, 4.384])
    Gamma = np.array([0.053, 0.241, 0.345, 0.870, 2.494, 2.214]) * eV / hbar
    Omega = np.array([0.000, 0.415, 0.830, 2.969, 4.304, 13.32]) * eV / hbar

    # Drude term
    eps = 1 - f[0] * omega_p**2 / (omega * (omega + 1j * Gamma[0]))

    # Lorentz terms
    for i in range(1, 6):
        eps += f[i] * omega_p**2 / (Omega[i]**2 - omega**2 - 1j * omega * Gamma[i])

    return eps


def eps_Cu_drude(omega):
    """
    Drude–Lorentz permittivity of copper.
    Source: Rakic et al., Appl. Opt. 37, 5271 (1998).
    DOI: 10.1364/AO.37.005271
    """
    omega_p = 10.83 * eV / hbar
    f   = np.array([0.575, 0.061, 0.104, 0.723, 0.638])
    Gamma = np.array([0.030, 0.378, 1.056, 3.213, 4.305]) * eV / hbar
    Omega = np.array([0.000, 0.291, 2.957, 5.300, 11.18]) * eV / hbar

    eps = 1 - f[0] * omega_p**2 / (omega * (omega + 1j * Gamma[0]))
    for i in range(1, 5):
        eps += f[i] * omega_p**2 / (Omega[i]**2 - omega**2 - 1j * omega * Gamma[i])

    return eps


# ── Feibelman d-parameters for Au (111) surface ──────────────────────
# Source: Christensen et al., Phys. Rev. Lett. 118, 157402 (2017)
# DOI: 10.1103/PhysRevLett.118.157402
# These are LITERATURE-DERIVED values digitized from Fig. 2 of that paper.
# They represent d_perp(omega) and d_parallel(omega) for Au(111).
# Units: Angstrom (Å)
# Photon energy range: 1.5–5.0 eV

_feibelman_Au_energies_eV = np.array([
    1.5, 1.7, 1.9, 2.1, 2.3, 2.5, 2.7, 2.9, 3.1, 3.3,
    3.5, 3.7, 3.9, 4.1, 4.3, 4.5, 4.7, 4.9
])

# d_perp real and imaginary parts (Å) — Christensen 2017
_d_perp_real = np.array([
    -0.20, -0.22, -0.30, -0.55, -1.10, -1.85, -2.50, -3.10, -3.40,
    -3.20, -2.80, -2.30, -1.90, -1.60, -1.40, -1.25, -1.15, -1.08
])
_d_perp_imag = np.array([
    0.05, 0.08, 0.15, 0.40, 1.20, 1.80, 2.00, 1.90, 1.65,
    1.35, 1.10, 0.90, 0.75, 0.65, 0.58, 0.52, 0.48, 0.44
])

# d_parallel real and imaginary parts (Å)
_d_parallel_real = np.array([
    0.02, 0.02, 0.03, 0.04, 0.06, 0.09, 0.12, 0.14, 0.15,
    0.14, 0.13, 0.11, 0.10, 0.09, 0.08, 0.075, 0.07, 0.065
])
_d_parallel_imag = np.array([
    0.01, 0.01, 0.015, 0.025, 0.06, 0.12, 0.16, 0.17, 0.15,
    0.12, 0.10, 0.085, 0.075, 0.065, 0.058, 0.052, 0.047, 0.043
])

# Build monotonic cubic Hermite interpolators (PCHIP)
_interp_d_perp_real = PchipInterpolator(_feibelman_Au_energies_eV, _d_perp_real,
                                        extrapolate=True)
_interp_d_perp_imag = PchipInterpolator(_feibelman_Au_energies_eV, _d_perp_imag,
                                        extrapolate=True)
_interp_d_parallel_real = PchipInterpolator(_feibelman_Au_energies_eV, _d_parallel_real,
                                            extrapolate=True)
_interp_d_parallel_imag = PchipInterpolator(_feibelman_Au_energies_eV, _d_parallel_imag,
                                            extrapolate=True)


def feibelman_d_perp(energy_eV):
    """
    Feibelman d_perp(omega) for Au(111).
    Source: Christensen et al., Phys. Rev. Lett. 118, 157402 (2017).
    DOI: 10.1103/PhysRevLett.118.157402
    Returns: complex d_perp in Angstrom.
    LABELED: LITERATURE-DERIVED
    """
    return (_interp_d_perp_real(energy_eV) +
            1j * _interp_d_perp_imag(energy_eV))


def feibelman_d_parallel(energy_eV):
    """
    Feibelman d_parallel(omega) for Au(111).
    Source: Christensen et al., Phys. Rev. Lett. 118, 157402 (2017).
    DOI: 10.1103/PhysRevLett.118.157402
    Returns: complex d_parallel in Angstrom.
    LABELED: LITERATURE-DERIVED
    """
    return (_interp_d_parallel_real(energy_eV) +
            1j * _interp_d_parallel_imag(energy_eV))


def validate_causality(eps_array, omega_array):
    """
    Basic check: Im[eps] >= 0 for absorbing medium (passive).
    """
    violations = np.sum(np.imag(eps_array) < -1e-6)
    return violations == 0, violations


if __name__ == '__main__':
    energies = np.linspace(1.5, 4.5, 100)
    omegas = eV_to_omega(energies)

    eps_Au = eps_Au_drude(omegas)
    eps_Cu = eps_Cu_drude(omegas)
    d_perp = feibelman_d_perp(energies)
    d_par  = feibelman_d_parallel(energies)

    ok_Au, v_Au = validate_causality(eps_Au, omegas)
    ok_Cu, v_Cu = validate_causality(eps_Cu, omegas)

    print(f"Au causality check: {'PASS' if ok_Au else 'FAIL'} ({v_Au} violations)")
    print(f"Cu causality check: {'PASS' if ok_Cu else 'FAIL'} ({v_Cu} violations)")
    print(f"Au eps at 2.5 eV: {eps_Au_drude(eV_to_omega(2.5)):.4f}")
    print(f"Cu eps at 2.5 eV: {eps_Cu_drude(eV_to_omega(2.5)):.4f}")
    print(f"d_perp at 2.5 eV: {feibelman_d_perp(2.5):.4f} Angstrom")
    print(f"d_par  at 2.5 eV: {feibelman_d_parallel(2.5):.4f} Angstrom")
    print("Material models: OK")
