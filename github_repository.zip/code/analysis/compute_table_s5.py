import sys, os
sys.path.insert(0, os.path.abspath('feibelman-quantum-dynamics'))

from src.materials import eV_to_omega, eps_Au_drude
from src.feibelman import feibelman_d_perp, feibelman_d_parallel
from src.green_tensor import compute_cross_green_tensor
from src.quantum_dynamics import solve_exact_kossakowski

E_eV = 2.5
omega = eV_to_omega(E_eV)
eps_m = eps_Au_drude(omega)
d_p = feibelman_d_perp(E_eV)
d_s = feibelman_d_parallel(E_eV)
z = 5e-9
R12 = 15e-9

delta_u = 6.0 / 500.0  # 0.012

u_cutoffs = [4.0, 6.0, 8.0, 10.0, 12.0, 15.0, 20.0, 30.0]

print(f"{'u_max':>5} | {'N_quad':>6} | {'F_P_perp':>8} | {'Gamma12':>8} | {'g12':>8} | {'lam_min':>8} | {'lam_max':>8} | {'C_max':>6} | {'tau_C':>6}")
print("-" * 88)

rows = []
for u_max in u_cutoffs:
    n_quad = int(round(u_max / delta_u))
    res = compute_cross_green_tensor(omega, z, z, R12, eps_m, model='feibelman',
                                    d_perp_A=d_p, d_par_A=d_s, u_max=u_max, n_quad=n_quad)
    
    fp_perp = res['Gamma11']
    gamma12 = res['Gamma12']
    g12 = res['g12']
    lam_min = fp_perp - abs(gamma12)
    lam_max = fp_perp + abs(gamma12)
    
    rates = {'Gamma1': fp_perp, 'Gamma2': fp_perp, 'Gamma12': gamma12, 'g12': g12}
    dyn = solve_exact_kossakowski(rates, omega_q=10.0, gamma0=1.0, t_max=1.5, n_t=400)
    c_max = dyn['c_max']
    tau_c = dyn['tau_C']
    
    rows.append({
        'u_max': u_max, 'n_quad': n_quad, 'fp_perp': fp_perp,
        'gamma12': gamma12, 'g12': g12, 'lam_min': lam_min, 'lam_max': lam_max,
        'c_max': c_max, 'tau_c': tau_c
    })
    print(f"{u_max:5.1f} | {n_quad:6d} | {fp_perp:8.2f} | {gamma12:8.2f} | {g12:8.2f} | {lam_min:8.2f} | {lam_max:8.2f} | {c_max:6.3f} | {tau_c:6.3f}")

print("\nLaTeX table rows:")
for r in rows:
    bold = r['u_max'] == 6.0
    u_str = f"\\textbf{{{r['u_max']:.1f}}}" if bold else f"{r['u_max']:.1f}"
    fp_str = f"\\textbf{{{r['fp_perp']:.2f}}}" if bold else f"{r['fp_perp']:.2f}"
    g12_str = f"\\textbf{{{r['gamma12']:.2f}}}" if bold else f"{r['gamma12']:.2f}"
    g_str = f"\\mathbf{{{r['g12']:.2f}}}" if bold else f"{r['g12']:.2f}"
    lmin_str = f"\\textbf{{{r['lam_min']:.2f}}}" if bold else f"{r['lam_min']:.2f}"
    lmax_str = f"\\textbf{{{r['lam_max']:.2f}}}" if bold else f"{r['lam_max']:.2f}"
    c_str = f"\\textbf{{{r['c_max']:.3f}}}" if bold else f"{r['c_max']:.3f}"
    tau_str = f"\\textbf{{{r['tau_c']:.3f}}}" if bold else (f"> 0.50" if r['tau_c'] >= 0.5 else f"{r['tau_c']:.3f}")
    
    print(f"{u_str} & {fp_str} & {g12_str} & {g_str} & {lmin_str} & {lmax_str} & {c_str} & {tau_str} \\\\")
