"""
weave_inline_figures.py
=======================
Inserts Figures 1-11 and Tables 1-4 directly inline in latex/main.tex
next to their primary text callouts, removes the trailing appendix dump,
and configures \\graphicspath so that all figures are immediately visible.
"""

import os
import re

TEX_PATH = os.path.join(os.path.dirname(__file__), '..', '..', 'latex', 'main.tex')
TEX_PATH = os.path.abspath(TEX_PATH)

with open(TEX_PATH, 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Preamble update: add graphicspath
if r'\graphicspath' not in content:
    content = content.replace(
        r'\usepackage{graphicx}',
        "\\usepackage{graphicx}\n\\graphicspath{{figures/}{../figures/png/}{../figures/pdf/}}"
    )

# 2. Extract figure and table blocks from trailing section
idx_figures = content.find('%% FIGURES')
if idx_figures == -1:
    idx_figures = content.find(r'\begin{figure}')

body_text = content[:idx_figures]
trailing_text = content[idx_figures:]

fig_pattern = re.compile(r'(\\begin\{figure\}.*?\\end\{figure\})', re.DOTALL)
figures = fig_pattern.findall(trailing_text)

tab_pattern = re.compile(r'(\\begin\{table\}.*?\\end\{table\})', re.DOTALL)
tables = tab_pattern.findall(trailing_text)

fig_dict = {}
for fig in figures:
    m = re.search(r'\\label\{(fig:.*?)\}', fig)
    if m:
        # Standardize graphicspath inside includegraphics
        clean_fig = fig.replace('../figures/png/', 'figures/')
        fig_dict[m.group(1)] = clean_fig

tab_dict = {}
for tab in tables:
    m = re.search(r'\\label\{(tab:.*?)\}', tab)
    if m:
        tab_dict[m.group(1)] = tab

print(f"Extracted {len(fig_dict)} figures: {list(fig_dict.keys())}")
print(f"Extracted {len(tab_dict)} tables: {list(tab_dict.keys())}")

# 3. Weave inline into body_text
# Insertion 1: Fig 1 and Fig 3 under Section 2 preamble (after domain are depicted in \Cref{fig:fig03}.)
anchor_1 = r"domain are depicted in \Cref{fig:fig03}."
insert_1 = anchor_1 + "\n\n" + fig_dict['fig:fig01'] + "\n\n" + fig_dict['fig:fig03']
if anchor_1 in body_text:
    body_text = body_text.replace(anchor_1, insert_1, 1)
    print("Placed Figure 1 and Figure 3 inline.")
else:
    print("WARNING: anchor_1 not found!")

# Insertion 2: Table 3 (tab:materials) under Section 2.1 (after and their sources.)
anchor_2 = r"and their sources."
insert_2 = anchor_2 + "\n\n" + tab_dict['tab:materials']
if anchor_2 in body_text:
    body_text = body_text.replace(anchor_2, insert_2, 1)
    print("Placed Table 3 (materials) inline.")
else:
    print("WARNING: anchor_2 not found!")

# Insertion 3: Table 4 (tab:sim_parameters) under Section 2.3 Numerical Implementation
anchor_3 = r"\geq 300$ (see Section~\ref{sec:convergence})."
insert_3 = anchor_3 + "\n\n" + tab_dict['tab:sim_parameters']
if anchor_3 in body_text:
    body_text = body_text.replace(anchor_3, insert_3, 1)
    print("Placed Table 4 (sim_parameters) inline.")
else:
    print("WARNING: anchor_3 not found!")

# Insertion 4: Fig 2 under Section 3.1 Material Validation (after charge-density corrections in this spectral range.)
anchor_4 = r"charge-density corrections in this spectral range."
insert_4 = anchor_4 + "\n\n" + fig_dict['fig:fig02']
if anchor_4 in body_text:
    body_text = body_text.replace(anchor_4, insert_4, 1)
    print("Placed Figure 2 inline.")
else:
    print("WARNING: anchor_4 not found!")

# Insertion 5: Fig 4 and Table 1 (tab:convergence) under Section 3.2 Convergence
anchor_5 = r"\Cref{tab:convergence} provides the complete quantitative convergence matrix."
insert_5 = anchor_5 + "\n\n" + fig_dict['fig:fig04'] + "\n\n" + tab_dict['tab:convergence']
if anchor_5 in body_text:
    body_text = body_text.replace(anchor_5, insert_5, 1)
    print("Placed Figure 4 and Table 1 (convergence) inline.")
else:
    print("WARNING: anchor_5 not found!")

# Insertion 6: Fig 5 under Section 3.3 LDOS Spectra (after most pronounced near the interband transition.)
anchor_6 = r"most pronounced near the interband transition."
insert_6 = anchor_6 + "\n\n" + fig_dict['fig:fig05']
if anchor_6 in body_text:
    body_text = body_text.replace(anchor_6, insert_6, 1)
    print("Placed Figure 5 inline.")
else:
    print("WARNING: anchor_6 not found!")

# Insertion 7: Fig 6 under Section 3.4 Purcell Distance (after local-model predictions may systematically misassign coupling strengths.)
anchor_7 = r"local-model predictions may systematically misassign coupling strengths."
insert_7 = anchor_7 + "\n\n" + fig_dict['fig:fig06']
if anchor_7 in body_text:
    body_text = body_text.replace(anchor_7, insert_7, 1)
    print("Placed Figure 6 inline.")
else:
    print("WARNING: anchor_7 not found!")

# Insertion 8: Fig 7 under Section 3.5 Parameter-Space Analysis (after parameters are largest in magnitude.)
anchor_8 = r"$1 \leq z \leq 5$\,nm and $2.0 \leq E \leq 3.5$\,eV."
insert_8 = anchor_8 + "\n\n" + fig_dict['fig:fig07']
if anchor_8 in body_text:
    body_text = body_text.replace(anchor_8, insert_8, 1)
    print("Placed Figure 7 inline.")
else:
    print("WARNING: anchor_8 not found!")

# Insertion 9: Fig 8 under Section 3.6 Au vs Cu (after reduced electromagnetic coupling.)
anchor_9 = r"reduced electromagnetic coupling."
insert_9 = anchor_9 + "\n\n" + fig_dict['fig:fig08']
if anchor_9 in body_text:
    body_text = body_text.replace(anchor_9, insert_9, 1)
    print("Placed Figure 8 inline.")
else:
    print("WARNING: anchor_9 not found!")

# Insertion 10: Fig 9 and Table 2 (tab:model_comparison) under Section 3.7 Model Comparison
anchor_10 = r"quantum surface-response for the LDOS of a planar interface."
insert_10 = anchor_10 + "\n\n" + fig_dict['fig:fig09'] + "\n\n" + tab_dict['tab:model_comparison']
if anchor_10 in body_text:
    body_text = body_text.replace(anchor_10, insert_10, 1)
    print("Placed Figure 9 and Table 2 inline.")
else:
    print("WARNING: anchor_10 not found!")

# Insertion 11: Fig 10 under Section 3.8 Sensitivity
anchor_11 = r"facets can introduce variations of this magnitude."
insert_11 = anchor_11 + "\n\n" + fig_dict['fig:fig10']
if anchor_11 in body_text:
    body_text = body_text.replace(anchor_11, insert_11, 1)
    print("Placed Figure 10 inline.")
else:
    print("WARNING: anchor_11 not found!")

# Insertion 12: Fig 11 under Section 3.9 Two-Qubit Dynamics
anchor_12 = r"of the two-qubit coherence."
insert_12 = anchor_12 + "\n\n" + fig_dict['fig:fig11']
if anchor_12 in body_text:
    body_text = body_text.replace(anchor_12, insert_12, 1)
    print("Placed Figure 11 inline.")
else:
    print("WARNING: anchor_12 not found!")

# Final cleanup: Ensure body ends with \end{document}
if not body_text.strip().endswith(r'\end{document}'):
    body_text = body_text.rstrip() + "\n\n\\end{document}\n"

with open(TEX_PATH, 'w', encoding='utf-8') as f:
    f.write(body_text)

print(f"\n[SUCCESS] Wrote updated {TEX_PATH} with all figures and tables inline.")
