"""
generate_cover_letter_docx.py
=============================
Generates publication-ready Microsoft Word (.docx) Cover Letter for
Computational Materials Today (Elsevier).
"""

import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
import os

def create_cover_letter_docx():
    doc = docx.Document()
    
    # Page Margins: 1 inch (2.54 cm)
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)
        
    style_normal = doc.styles['Normal']
    font = style_normal.font
    font.name = 'Times New Roman'
    font.size = Pt(11)
    font.color.rgb = RGBColor(0x20, 0x20, 0x20)
    
    # Date
    p_date = doc.add_paragraph()
    p_date.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r_date = p_date.add_run("Date: 22 October 2026")
    r_date.bold = True
    
    # Recipient
    p_rec = doc.add_paragraph()
    p_rec.paragraph_format.space_after = Pt(12)
    p_rec.add_run("To:\nThe Editors-in-Chief\nComputational Materials Today\nElsevier B.V.")
    
    # Subject
    p_subj = doc.add_paragraph()
    p_subj.paragraph_format.space_after = Pt(12)
    r_s1 = p_subj.add_run("Subject: ")
    r_s1.bold = True
    r_s2 = p_subj.add_run("Submission of Original Research Article: \"Feibelman-Corrected Green-Tensor Modeling of Quantum Emitters and Two-Qubit Dynamics at Planar Gold Interfaces\"")
    r_s2.bold = True
    
    def add_p(text, bold_prefix=None, space_after=6):
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(space_after)
        p.paragraph_format.line_spacing = 1.15
        if bold_prefix:
            r_pre = p.add_run(bold_prefix + " ")
            r_pre.bold = True
        p.add_run(text)
        return p

    add_p("Dear Editors-in-Chief,\n\n"
          "We are pleased to submit our original research article entitled \"Feibelman-Corrected Green-Tensor Modeling of Quantum Emitters and Two-Qubit Dynamics at Planar Gold Interfaces\" for consideration for publication in Computational Materials Today. This manuscript presents original computational research that has not been published previously and is not under consideration for publication elsewhere.")
          
    add_p("Accurate modeling of electromagnetic interactions at metal–dielectric interfaces is central to the design of advanced nanophotonic, plasmonic, and quantum materials. However, conventional classical electrodynamics based on sharp-boundary local dielectric functions fails at nanometer-scale separations, systematically overestimating near-field coupling and Purcell enhancement due to the unphysical neglect of quantum surface electronic screening, nonlocality, and electron spill-out. While ab initio time-dependent density functional theory (TD-DFT) provides microscopic surface-response data, its severe computational scaling prohibits direct application to multi-emitter open quantum dynamics at optical frequencies.",
          bold_prefix="Scientific Problem:")
          
    add_p("To bridge this fundamental multiscale materials modeling gap, we develop a transparent, openly reproducible computational pipeline that connects literature-derived Feibelman surface-response parameters (d_perp(omega) and d_parallel(omega)) for Au(111) to planar generalized boundary conditions (GBC), evaluates the planar dyadic scattering Green tensor via semi-analytical Sommerfeld integration, and propagates these rigorous material-response inputs into two-qubit open quantum system master equations. Crucially, our framework evaluates both the coherent dipole–dipole exchange rate g_12 and mutual dissipative coupling Gamma_12 directly from the real and imaginary parts of the off-diagonal dyadic Green tensor without phenomenological rate scaling approximations. We perform systematic, side-by-side quantitative comparisons among local Drude, hydrodynamic nonlocal, and Feibelman-corrected surface models.",
          bold_prefix="Main Contribution and Computational Framework:")

    add_p("Using verified numerical parameters (E = 2.5 eV, z = 5 nm, lateral separation R_12 = 15 nm above Au), our computational framework demonstrates:\n"
          "1. Quantum Near-Field Suppression: Feibelman surface response substantially suppresses the magnitude of the near-field Purcell enhancement relative to local Drude theory over the investigated distance range, yielding approximately 57% suppression at z = 5 nm and up to 62% suppression at the lower continuum computational boundary z = 0.5 nm (orientationally averaged Purcell factor <F_P> = 1.27 vs. 2.94 at 5 nm).\n"
          "2. Nonlocal Model Comparison: For flat interfaces, the standard hydrodynamic nonlocal model provides only marginal corrections (< 2%), indicating that the dominant nonclassical correction among the models considered in planar geometry stems from electronic charge centroid shifts (d_perp) rather than hydrodynamic convective pressure.\n"
          "3. Surface Sensitivity Hierarchy: Logarithmic sensitivity analysis demonstrates that the normal surface parameter d_perp dominates the optical response (sensitivity slope d(ln F_P)/d(ln s) ~ 0.82), whereas tangential current slip d_parallel exerts negligible influence (slope ~ 0.03).\n"
          "4. Open Quantum Dynamics and Kossakowski Positivity: The derived Kossakowski decay matrix satisfies strict positive semidefiniteness (lambda_min >= 0) across all investigated environments, guaranteeing complete positivity and trace preservation. Under our primary exact Kossakowski diagonalization, the peak entanglement concurrence reaches C_max ~ 0.696 with an entanglement lifetime tau_C ~ 0.264 gamma_0^-1 (Feibelman) compared to C_max ~ 0.693 and tau_C ~ 0.268 gamma_0^-1 (Local). In contrast, heuristic partitioned collapse channels artificially over-damp single-emitter decay, yielding C_max ~ 0.571 and tau_C ~ 0.038 gamma_0^-1; we explicitly derive the underlying effective decay matrix Gamma_eff to explain this mathematical divergence.",
          bold_prefix="Key Quantitative Findings:")

    add_p("To our knowledge, the manuscript provides an openly reproducible computational workflow that systematically connects literature-derived Feibelman surface-response data, planar cross Green-tensor evaluation, and two-qubit open quantum dynamics within a single benchmarked pipeline.",
          bold_prefix="Novelty Claim:")

    add_p("This work is presented specifically as a computational-materials study rather than a purely quantum-information manuscript. It addresses fundamental multiscale modeling challenges in metallic materials: connecting atomistic/surface electronic response to mesoscopic electrodynamics, formulating robust numerical Sommerfeld integration algorithms, comparing competing material-response paradigms, and delivering a thoroughly documented, modular computational tool for researchers in computational physics and nanoscale materials science.",
          bold_prefix="Fit to Computational Materials Today:")

    add_p("In accordance with Elsevier's data sharing standards, we have assembled a complete standalone companion package, feibelman-quantum-dynamics/, supplied alongside the manuscript in the supplementary archive. The package includes modular Python source libraries (src/), figure-by-figure reproduction scripts (scripts/), unit tests (tests/), and verified datasets (data/). A comprehensive computational error budget and numerical convergence analysis (Delta z = 0.5 nm spatial sampling step, N_quad = 500 quadrature intervals) confirm that the selected N_quad = 500 production setting yields F_P^perp = 41.66 (Local) and 42.13 (Feibelman), agreeing with the N_quad = 600 reference calculation within ~0.52% specifically for the perpendicular Purcell factor (0.53% Local, 0.52% Feibelman, with numerical variation strictly bounded below 0.7% across all N >= 100). The computational code, numerical datasets, and figure-generation scripts will be made publicly available upon publication (an anonymized companion archive is provided with the submission for peer review). Upon publication, the complete computational package will be made publicly accessible under the MIT license and archived with a persistent DOI.",
          bold_prefix="Reproducibility and Open Code Package:")

    add_p("We emphasize full scientific transparency: all Feibelman parameters are literature-derived from the published TD-DFT benchmarks of Christensen et al. (PRL 2017); no new ab initio TD-DFT calculations are claimed. Furthermore, we explicitly acknowledge framework limitations, including the facet specificity of Au(111), the current lack of equivalent first-principles Feibelman data for Cu, the breakdown of continuum electrodynamics below 0.5 nm due to atomistic corrugation and orbital overlap, and the Markovian approximation.\n\n"
          "All authors have reviewed and approved the manuscript. The authors declare no competing financial or personal interests. This work was supported by the Ministry of Education (MoE), Government of India, through doctoral research fellowship funding to P.S., and computational resources provided by IIT Roorkee and IISc Bangalore.\n\n"
          "We look forward to the editorial evaluation of our manuscript and thank you for your consideration.",
          bold_prefix="Scientific Integrity and Declarations:")

    p_sign = doc.add_paragraph()
    p_sign.paragraph_format.space_before = Pt(12)
    p_sign.paragraph_format.line_spacing = 1.15
    p_sign.add_run("Sincerely,\n\n")
    r_auth = p_sign.add_run("Priyanka Sharma (Corresponding Author), Rajesh Kumar, and Vikramaditya Singh\n")
    r_auth.bold = True
    p_sign.add_run("Department of Physics and Materials Science, Indian Institute of Technology Roorkee, Roorkee 247667, Uttarakhand, India\n"
                   "Email: psharma@ph.iitr.ac.in")
                   
    out_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'cover_letter', 'Cover_Letter_Computational_Materials_Today.docx'))
    doc.save(out_path)
    print(f"[SUCCESS] Cover letter docx saved: {out_path}")

if __name__ == '__main__':
    create_cover_letter_docx()
