"""
audit_compiled_pdfs.py
======================
Comprehensive verification of all 4 compiled PDFs in pdf/ directory:
1. Figure S2 caption in supplementary_information.pdf and supplementary_information_blinded.pdf
2. Table 7 benchmarks in main.pdf and main_blinded.pdf
3. Anonymization audit in blinded PDFs
"""

import os
import re
import sys
import pypdf

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
PDF_DIR = os.path.join(BASE_DIR, 'pdf')

def extract_clean_text(pdf_path):
    reader = pypdf.PdfReader(pdf_path)
    full_text = '\n'.join([p.extract_text() or '' for p in reader.pages])
    # Remove hyphens at line breaks or whitespace: 'inde-\n pendently' -> 'independently'
    text = re.sub(r'-\s+', '', full_text)
    # Also strip stray intra-word hyphens if followed by newline
    text = re.sub(r'-\r?\n\s*', '', text)
    # Normalize spaces
    text = re.sub(r'\s+', ' ', text)
    return text

def run_audit():
    print("=" * 70)
    print("RUNNING COMPREHENSIVE PDF ARTIFACT AUDIT")
    print("=" * 70)
    
    all_passed = True
    
    # -------------------------------------------------------------------------
    # 1. SI Verification (Figure S2 Caption)
    # -------------------------------------------------------------------------
    si_files = ['supplementary_information.pdf', 'supplementary_information_blinded.pdf']
    
    for fname in si_files:
        fpath = os.path.join(PDF_DIR, fname)
        print(f"\n--- Checking SI: {fname} ---")
        text = extract_clean_text(fpath)
        
        # Check forbidden stale numbers
        if '<0.035%' in text or '0.035%' in text:
            print("  [FAIL] Stale error bound '0.035%' found!")
            all_passed = False
        else:
            print("  [PASS] Stale '<0.035%' error bound ABSENT.")
            
        # Check duplicate "Supplementary Figure S2"
        if "Figure S2: Supplementary Figure S2" in text:
            print("  [FAIL] Duplicate 'Figure S2: Supplementary Figure S2' found!")
            all_passed = False
        else:
            print("  [PASS] No duplicate 'Figure S2: Supplementary Figure S2' found.")
            
        # Check required caption components
        required_si = [
            ("Figure S2 prefix", "Figure S2: Numerical convergence analysis"),
            ("Nquad=500 setting", "production setting (Nquad = 500) yields <0.6% relative deviation"),
            ("Local 0.53% & Feibelman 0.52%", "0.53% for Local Drude and 0.52% for Feibelman"),
            ("Distance grid convergence", "verifying <0.04% error"),
            ("Spatial step Delta z = 0.5 nm", "0.5 nm spatial sampling step")
        ]
        
        spaceless_text = re.sub(r'\s+', '', text.lower())
        for desc, snippet in required_si:
            spaceless_snippet = re.sub(r'\s+', '', snippet.lower())
            if spaceless_snippet in spaceless_text:
                print(f"  [PASS] Found {desc}: '{snippet}'")
            else:
                print(f"  [FAIL] Missing {desc}: '{snippet}'")
                all_passed = False

    # -------------------------------------------------------------------------
    # 2. Main Verification (Table 7 Benchmarks & Relabeling)
    # -------------------------------------------------------------------------
    main_files = ['main.pdf', 'main_blinded.pdf']
    
    for fname in main_files:
        fpath = os.path.join(PDF_DIR, fname)
        print(f"\n--- Checking Main: {fname} ---")
        text = extract_clean_text(fpath)
        spaceless_text = re.sub(r'\s+', '', text.lower())
        
        # Check forbidden Dicke limit
        if "analyticaldickesuperradiancelimit" in spaceless_text:
            print("  [FAIL] Stale 'Analytical Dicke superradiance limit' found!")
            all_passed = False
        else:
            print("  [PASS] Stale 'Analytical Dicke superradiance limit' ABSENT.")

        # Check forbidden undefined kappa
        if "kappa/omega" in spaceless_text or "kappa/omega_q" in spaceless_text:
            print("  [FAIL] Undefined kappa/omega_q found in text!")
            all_passed = False
        else:
            print("  [PASS] Undefined kappa/omega_q ABSENT.")
            
        required_main = [
            ("Level 1 Planar benchmark", "agreement with independently evaluated analytical planar green-tensor benchmark"),
            ("Level 2 Feibelman framework", "consistency with the published feibelman surface-response/gbc framework"),
            ("Level 2 Au(111) configuration", "for the present au(111) planar configuration"),
            ("Level 3 Lehmberg formalism", "lehmberg"),
            ("Level 3 limit label", "analytical free-space green-tensor limit"),
            ("Level 3 C_max=0.991 Kossakowski", "0.991 under exact kossakowski diagonalization"),
            ("Level 3 C_max=0.981 partitioned", "0.981 under secondary partitioned-collapse formulation"),
            ("Level 3 Consistency criterion", "agreement with the independently evaluated analytical free-space two-emitter benchmark using the same"),
            ("Table 8 Markov weak memory", "weaksystembathmemoryregime"),
            ("Yang 2018 PRL GBC citation", "generalizeddielectricboundaryconditionderivationofyangetal")
        ]
        
        spaceless_text = re.sub(r'[\s\-\u2010-\u2015]+', '', text.lower())
        for desc, snippet in required_main:
            spaceless_snippet = re.sub(r'[\s\-\u2010-\u2015]+', '', snippet.lower())
            if spaceless_snippet in spaceless_text:
                print(f"  [PASS] Found {desc}: '{snippet}'")
            else:
                print(f"  [FAIL] Missing {desc}: '{snippet}'")
                all_passed = False

    # -------------------------------------------------------------------------
    # 3. Cover Letter Verification
    # -------------------------------------------------------------------------
    print("\n--- Checking Cover Letter: Cover_Letter_Computational_Materials_Today.pdf ---")
    cl_path = os.path.join(PDF_DIR, 'Cover_Letter_Computational_Materials_Today.pdf')
    cl_text = extract_clean_text(cl_path)
    if 'spatial sampling step' in cl_text:
        print("  [PASS] 'spatial sampling step' present in Cover Letter.")
    else:
        print("  [FAIL] 'spatial sampling step' MISSING from Cover Letter!")
        all_passed = False

    if '0.5 nm mesh' in cl_text or r'0.5\,nm mesh' in cl_text:
        print("  [FAIL] Stale '0.5 nm mesh' found in Cover Letter!")
        all_passed = False
    else:
        print("  [PASS] Stale '0.5 nm mesh' ABSENT from Cover Letter.")

    # -------------------------------------------------------------------------
    # 4. Blinded PDFs Anonymization Audit
    # -------------------------------------------------------------------------
    blinded_files = ['main_blinded.pdf', 'supplementary_information_blinded.pdf']
    author_tokens = [
        "Priyanka Sharma", "Rajesh Kumar", "Vikramaditya Singh",
        "psharma@ph.iitr.ac.in", "Roorkee", "Department of Physics and Materials Science"
    ]
    
    print("\n--- Running Blinded Manuscript Anonymization Audit ---")
    for fname in blinded_files:
        fpath = os.path.join(PDF_DIR, fname)
        text = extract_clean_text(fpath)
        file_clean = True
        for token in author_tokens:
            if token.lower() in text.lower():
                print(f"  [FAIL BLINDING] '{token}' found in {fname}!")
                file_clean = False
                all_passed = False
        if file_clean:
            print(f"  [PASS BLINDING] {fname} is 100% anonymized (0 author/institutional identifiers).")

    print("\n" + "=" * 70)
    if all_passed:
        print("ALL VERIFICATION CHECKS PASSED: 100% COMPLIANT WITH USER SPECIFICATIONS.")
    else:
        print("SOME CHECKS FAILED.")
    print("=" * 70)
    return all_passed

if __name__ == '__main__':
    success = run_audit()
    sys.exit(0 if success else 1)
