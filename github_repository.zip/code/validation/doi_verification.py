"""
doi_verification.py
===================
DOI verification engine using the Crossref public API.
Records verification status for every reference in the bibliography.

Rule: References with failed DOI verification are EXCLUDED from the manuscript.
"""

import requests
import csv
import json
import time
import os

CROSSREF_BASE = "https://api.crossref.org/works/"
DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'references'))
os.makedirs(DATA_DIR, exist_ok=True)


# ── Candidate reference list ──────────────────────────────────────────
# All references proposed for inclusion in the manuscript.
# DOI must be verified before inclusion.
CANDIDATE_REFERENCES = [
    {
        'ref_id': 'R01', 'tag': 'Ford1984',
        'title': 'Electromagnetic interactions of molecules with metal surfaces',
        'authors': 'Ford GW, Weber WH',
        'journal': 'Physics Reports',
        'year': 1984, 'volume': '113', 'pages': '195-287',
        'doi': '10.1016/0370-1573(84)90098-X'
    },
    {
        'ref_id': 'R02', 'tag': 'Christensen2017',
        'title': 'Quantum Corrections in Nanoplasmonics: Shape, Scale, and Material',
        'authors': 'Christensen T, Yan W, Jauho A-P, Soljacic M, Mortensen NA',
        'journal': 'Physical Review Letters',
        'year': 2017, 'volume': '118', 'pages': '157402',
        'doi': '10.1103/PhysRevLett.118.157402'
    },
    {
        'ref_id': 'R03', 'tag': 'Toscano2015',
        'title': 'Resonance shifts and spill-out effects in self-consistent hydrodynamic nanoplasmonics',
        'authors': 'Toscano G, Straubel J, Kwiatkowski A, Rockstuhl C, Evers F, Xu H, Mortensen NA, Wubs M',
        'journal': 'Nature Communications',
        'year': 2015, 'volume': '6', 'pages': '7132',
        'doi': '10.1038/ncomms8132'
    },
    {
        'ref_id': 'R04', 'tag': 'Raza2015',
        'title': 'Nonlocal optical response in metallic nanostructures',
        'authors': 'Raza S, Bozhevolnyi SI, Wubs M, Mortensen NA',
        'journal': 'Journal of Physics: Condensed Matter',
        'year': 2015, 'volume': '27', 'pages': '183204',
        'doi': '10.1088/0953-8984/27/18/183204'
    },
    {
        'ref_id': 'R05', 'tag': 'Yang2019',
        'title': 'Optical forces on small particles: attractive and repulsive nature and plasmon-resonance conditions',
        'authors': 'Yang Y, Settineri D, Kong X, Strauss HM, Bhatt A, Park S, Frenklach M, Bhattacharya S, Ruzicka B, Bhatt DL',
        'journal': 'Physical Review B',
        'year': 2019, 'volume': '100', 'pages': '035406',
        'doi': '10.1103/PhysRevB.100.035406'
    },
    {
        'ref_id': 'R06', 'tag': 'GonzalezTudela2011',
        'title': 'Entanglement of Two Qubits Mediated by One-Dimensional Plasmonic Waveguides',
        'authors': 'Gonzalez-Tudela A, Martin-Cano D, Moreno E, Martin-Moreno L, Tejedor C, Garcia-Vidal FJ',
        'journal': 'Physical Review Letters',
        'year': 2011, 'volume': '106', 'pages': '020501',
        'doi': '10.1103/PhysRevLett.106.020501'
    },
    {
        'ref_id': 'R07', 'tag': 'Dzsotjan2010',
        'title': 'Quantum emitters coupled to surface plasmons of a nanowire: A Green\'s function approach',
        'authors': 'Dzsotjan D, Sorensen AS, Fleischhauer M',
        'journal': 'Physical Review B',
        'year': 2010, 'volume': '82', 'pages': '075427',
        'doi': '10.1103/PhysRevB.82.075427'
    },
    {
        'ref_id': 'R08', 'tag': 'MartinCano2010',
        'title': 'Resonance Energy Transfer and Superradiance Mediated by Plasmonic Nanowaveguides',
        'authors': 'Martin-Cano D, Martin-Moreno L, Garcia-Vidal FJ, Moreno E',
        'journal': 'Nano Letters',
        'year': 2010, 'volume': '10', 'pages': '3129-3134',
        'doi': '10.1021/nl101876f'
    },
    {
        'ref_id': 'R09', 'tag': 'Wootters1998',
        'title': 'Entanglement of Formation of an Arbitrary State of Two Qubits',
        'authors': 'Wootters WK',
        'journal': 'Physical Review Letters',
        'year': 1998, 'volume': '80', 'pages': '2245-2248',
        'doi': '10.1103/PhysRevLett.80.2245'
    },
    {
        'ref_id': 'R10', 'tag': 'Rakic1998',
        'title': 'Optical properties of metallic films for vertical-cavity optoelectronic devices',
        'authors': 'Rakic AD, Djurisic AB, Elazar JM, Majewski ML',
        'journal': 'Applied Optics',
        'year': 1998, 'volume': '37', 'pages': '5271-5283',
        'doi': '10.1364/AO.37.005271'
    },
    {
        'ref_id': 'R11', 'tag': 'JohnsonChristy1972',
        'title': 'Optical Constants of the Noble Metals',
        'authors': 'Johnson PB, Christy RW',
        'journal': 'Physical Review B',
        'year': 1972, 'volume': '6', 'pages': '4370-4379',
        'doi': '10.1103/PhysRevB.6.4370'
    },
    {
        'ref_id': 'R12', 'tag': 'Feibelman1982',
        'title': 'Surface electromagnetic fields',
        'authors': 'Feibelman PJ',
        'journal': 'Progress in Surface Science',
        'year': 1982, 'volume': '12', 'pages': '287-407',
        'doi': '10.1016/0079-6816(82)90001-6'
    },
    {
        'ref_id': 'R13', 'tag': 'Mortensen2021',
        'title': 'Mesoscopic electrodynamics at metal surfaces — From quantum-corrected hydrodynamics to microscopic surface-response formalism',
        'authors': 'Mortensen NA',
        'journal': 'Nanophotonics',
        'year': 2021, 'volume': '10', 'pages': '2563-2616',
        'doi': '10.1515/nanoph-2021-0156'
    },
    {
        'ref_id': 'R14', 'tag': 'Babaze2022',
        'title': 'Quantum surface effects in the electromagnetic coupling between a quantum emitter and a plasmonic nanoantenna: time-dependent density functional theory vs. semiclassical Feibelman approach',
        'authors': 'Babaze A, Ogando E, Stamatopoulou PE, Tserkezis C, Mortensen NA, Aizpurua J, Borisov AG, Esteban R',
        'journal': 'Optics Express',
        'year': 2022, 'volume': '30', 'pages': '21159-21183',
        'doi': '10.1364/OE.456338'
    },
    {
        'ref_id': 'R15', 'tag': 'Novotny2012',
        'title': 'Principles of Nano-Optics',
        'authors': 'Novotny L, Hecht B',
        'journal': 'Cambridge University Press',
        'year': 2012, 'volume': 'Book', 'pages': '2nd edition',
        'doi': '10.1017/CBO9780511794193'
    },
    {
        'ref_id': 'R16', 'tag': 'Anger2006',
        'title': 'Enhancement and Quenching of Single-Molecule Fluorescence',
        'authors': 'Anger P, Bharadwaj P, Novotny L',
        'journal': 'Physical Review Letters',
        'year': 2006, 'volume': '96', 'pages': '113002',
        'doi': '10.1103/PhysRevLett.96.113002'
    },
    {
        'ref_id': 'R17', 'tag': 'Kuhlicke2014',
        'title': 'In Situ Electrostatic Trapping and Surface-Enhanced Raman Spectroscopy of Single Nanoparticles by a Bifocal Optical Tweezer',
        'authors': 'Kuhlicke A, Schell AW, Zoll J, Benson O',
        'journal': 'Applied Physics Letters',
        'year': 2014, 'volume': '105', 'pages': '073101',
        'doi': '10.1063/1.4893953'
    },
    {
        'ref_id': 'R18', 'tag': 'Yan2015',
        'title': 'Quantum corrections to the optical response of metallic and semiconducting nanostructures',
        'authors': 'Yan W',
        'journal': 'Physical Review B',
        'year': 2015, 'volume': '91', 'pages': '115416',
        'doi': '10.1103/PhysRevB.91.115416'
    },
    {
        'ref_id': 'R19', 'tag': 'Tserkezis2020',
        'title': 'Mie versus Nonclassical Effects in the Optical Properties of Small Metal Nanoparticles',
        'authors': 'Tserkezis C, Echarri AR, Encinar M, Borisov AG, Aizpurua J, Mortensen NA',
        'journal': 'Physical Review Research',
        'year': 2020, 'volume': '2', 'pages': '012024',
        'doi': '10.1103/PhysRevResearch.2.012024'
    },
    {
        'ref_id': 'R20', 'tag': 'Breuer2002',
        'title': 'The Theory of Open Quantum Systems',
        'authors': 'Breuer H-P, Petruccione F',
        'journal': 'Oxford University Press',
        'year': 2002, 'volume': 'Book', 'pages': '1st edition',
        'doi': '10.1093/acprof:oso/9780199213900.001.0001'
    },
]


def verify_doi(doi, ref_id, timeout=10):
    """Query Crossref API to verify a DOI."""
    url = f"{CROSSREF_BASE}{doi}"
    try:
        resp = requests.get(url, timeout=timeout,
                            headers={'User-Agent': 'doi-verifier/1.0 (research)'})
        if resp.status_code == 200:
            data = resp.json()['message']
            meta_title = data.get('title', [''])[0] if data.get('title') else ''
            meta_authors = data.get('author', [])
            meta_author_str = '; '.join(
                f"{a.get('family','')}" for a in meta_authors[:3]
            ) if meta_authors else ''
            meta_journal = ''
            if data.get('container-title'):
                meta_journal = data['container-title'][0]
            meta_year = ''
            if data.get('published-print'):
                meta_year = str(data['published-print']['date-parts'][0][0])
            elif data.get('published-online'):
                meta_year = str(data['published-online']['date-parts'][0][0])
            return {
                'resolves': True,
                'meta_title': meta_title[:80],
                'meta_authors': meta_author_str[:60],
                'meta_journal': meta_journal[:60],
                'meta_year': meta_year,
                'doi_status': 'VERIFIED',
            }
        elif resp.status_code == 404:
            return {'resolves': False, 'doi_status': 'NOT_FOUND',
                    'meta_title': '', 'meta_authors': '', 'meta_journal': '', 'meta_year': ''}
        else:
            return {'resolves': False, 'doi_status': f'HTTP_{resp.status_code}',
                    'meta_title': '', 'meta_authors': '', 'meta_journal': '', 'meta_year': ''}
    except Exception as e:
        return {'resolves': False, 'doi_status': f'ERROR: {str(e)[:40]}',
                'meta_title': '', 'meta_authors': '', 'meta_journal': '', 'meta_year': ''}


def run_verification():
    """Verify all candidate references."""
    results = []
    verified = 0
    rejected = 0
    duplicates = set()
    doi_seen  = set()

    print(f"Verifying {len(CANDIDATE_REFERENCES)} candidate references via Crossref...")

    for ref in CANDIDATE_REFERENCES:
        doi = ref['doi'].strip()
        dup = doi in doi_seen
        doi_seen.add(doi)

        print(f"  [{ref['ref_id']}] {doi} ...", end=' ')
        v = verify_doi(doi, ref['ref_id'])
        time.sleep(0.5)  # polite rate-limiting

        row = {
            'reference_id':               ref['ref_id'],
            'tag':                        ref['tag'],
            'title':                      ref['title'][:70],
            'authors':                    ref['authors'][:60],
            'journal':                    ref['journal'][:40],
            'year':                       ref['year'],
            'volume':                     ref['volume'],
            'pages_article_number':       ref['pages'],
            'doi':                        doi,
            'doi_resolves':               v['resolves'],
            'doi_metadata_title':         v['meta_title'],
            'doi_metadata_authors':       v['meta_authors'],
            'doi_metadata_journal':       v['meta_journal'],
            'doi_metadata_year':          v['meta_year'],
            'doi_status':                 v['doi_status'],
            'duplicate_status':           'DUPLICATE' if dup else 'UNIQUE',
            'arxiv_status':               'NA',
            'verification_source':        'Crossref API',
            'final_decision':             'INCLUDE' if v['resolves'] and not dup else 'EXCLUDE',
        }
        results.append(row)

        if v['resolves'] and not dup:
            verified += 1
            print(f"OK {v['doi_status']}")
        else:
            rejected += 1
            print(f"FAIL {v['doi_status']}")

    # Write CSV
    out_path = os.path.join(DATA_DIR, 'doi_verification.csv')
    fieldnames = list(results[0].keys())
    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(results)

    # Write audit report
    audit_path = os.path.join(DATA_DIR, 'reference_audit_report.md')
    included = [r for r in results if r['final_decision'] == 'INCLUDE']
    excluded = [r for r in results if r['final_decision'] == 'EXCLUDE']

    with open(audit_path, 'w') as f:
        f.write("# Reference Audit Report\n")
        f.write(f"**Date: 2026-10-21**\n\n")
        f.write(f"| Metric | Count |\n|---|---|\n")
        f.write(f"| Total candidates | {len(results)} |\n")
        f.write(f"| Verified (INCLUDE) | {len(included)} |\n")
        f.write(f"| Rejected (EXCLUDE) | {len(excluded)} |\n")
        f.write(f"| Duplicate DOIs removed | {len([r for r in results if r['duplicate_status']=='DUPLICATE'])} |\n")
        f.write(f"| DOI failures | {len([r for r in results if not r['doi_resolves']])} |\n")
        f.write(f"| arXiv exclusions | 0 |\n\n")

        f.write("## Included References\n\n")
        for r in included:
            f.write(f"- [{r['reference_id']}] {r['tag']}: {r['doi']} → {r['doi_status']}\n")

        if excluded:
            f.write("\n## Excluded References\n\n")
            for r in excluded:
                f.write(f"- [{r['reference_id']}] {r['tag']}: {r['doi']} → REASON: {r['doi_status']}/{r['duplicate_status']}\n")

    print(f"\nDOI verification complete:")
    print(f"  Verified: {len(included)}")
    print(f"  Excluded: {len(excluded)}")
    print(f"  CSV: {out_path}")
    print(f"  Audit: {audit_path}")

    return included


if __name__ == '__main__':
    run_verification()
