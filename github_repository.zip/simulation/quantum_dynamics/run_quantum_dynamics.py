"""
run_quantum_dynamics.py
========================
Simulation runner for two-qubit open quantum system dynamics.
Evaluates 300 temporal points using QuTiP mesolve master equation solver.
"""

import sys, os, csv
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'code', 'analysis'))
from quantum_dynamics import run_dynamics

def execute_dynamics():
    print("=" * 65)
    print("Running Two-Qubit Dynamics Solver (300 temporal data points)")
    print("=" * 65)

    # 300 data points across t in [0, 10 / gamma0]
    res_local = run_dynamics(2.942, 2.942, 0.88, omega_q=10.0, gamma0=1.0, t_max=10.0, n_t=300)
    res_feib  = run_dynamics(1.271, 1.271, 0.38, omega_q=10.0, gamma0=1.0, t_max=10.0, n_t=300)

    out_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'processed')
    os.makedirs(out_dir, exist_ok=True)
    out_file = os.path.join(out_dir, 'quantum_dynamics_300pts.csv')

    with open(out_file, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['time', 'pop1_local', 'concurrence_local', 'pop1_feib', 'concurrence_feib'])
        for i in range(len(res_local['tlist'])):
            w.writerow([
                f'{res_local["tlist"][i]:.4f}',
                f'{res_local["pop1"][i]:.6f}',
                f'{res_local["concurrence"][i]:.6f}',
                f'{res_feib["pop1"][i]:.6f}',
                f'{res_feib["concurrence"][i]:.6f}'
            ])

    print(f"[SUCCESS] Two-qubit dynamics complete, saved: {out_file}")

if __name__ == '__main__':
    execute_dynamics()
