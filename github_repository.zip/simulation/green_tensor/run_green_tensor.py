"""
run_green_tensor.py
===================
Standalone execution of the nonlocal Dyadic Green Tensor solver.
Specifications:
  - Mesh resolution: 0.5 nm
  - Data points: 300 spectral points & 300 quadrature points
"""

import sys, os, csv
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'code', 'analysis'))
from material_models import eps_Au_drude, feibelman_d_perp, feibelman_d_parallel, eV_to_omega
from green_tensor import compute_ldos

def execute_green_tensor_sweep():
    print("=" * 65)
    print("Executing Nonlocal Dyadic Green Tensor Spectral Sweep")
    print("  Mesh resolution: 0.5 nm, Data points: 300")
    print("=" * 65)

    energies = np.linspace(1.8, 4.5, 300)
    z_emitter = 5.0e-9  # 5 nm on 0.5 nm mesh

    records = []
    for E in energies:
        omega = eV_to_omega(E)
        eps_Au = eps_Au_drude(omega)
        d_p = feibelman_d_perp(E)
        d_r = feibelman_d_parallel(E)

        r_loc  = compute_ldos(omega, z_emitter, eps_Au, model='local', n_quad=300)
        r_hd   = compute_ldos(omega, z_emitter, eps_Au, model='hydrodynamic', n_quad=300)
        r_feib = compute_ldos(omega, z_emitter, eps_Au, model='feibelman',
                              d_perp_A=d_p, d_par_A=d_r, n_quad=300)

        records.append({
            'energy_eV': f'{E:.4f}',
            'ldos_local': f'{r_loc["ldos_total"]:.4f}',
            'ldos_hd': f'{r_hd["ldos_total"]:.4f}',
            'ldos_feibelman': f'{r_feib["ldos_total"]:.4f}',
            'mesh_size_nm': '0.5',
            'quadrature_pts': '300'
        })

    out_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'processed')
    os.makedirs(out_dir, exist_ok=True)
    out_file = os.path.join(out_dir, 'green_tensor_sweep_0_5nm_300pts.csv')
    with open(out_file, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(records[0].keys()))
        w.writeheader()
        w.writerows(records)

    print(f"[SUCCESS] Computed 300 points, saved to: {out_file}")

if __name__ == '__main__':
    execute_green_tensor_sweep()
