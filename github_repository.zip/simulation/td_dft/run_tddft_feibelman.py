"""
run_tddft_feibelman.py
======================
TD-DFT surface-response parameter extraction and interpolation module.
Loads literature ab initio Feibelman parameters and maps them to generalized
boundary conditions (GBC).
"""

import sys, os, csv
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'code', 'analysis'))
from material_models import feibelman_d_perp, feibelman_d_parallel

def export_tddft_parameters():
    print("=" * 65)
    print("Extracting TD-DFT Feibelman Surface-Response Parameters")
    print("  Data points: 300 spectral points (1.5 - 5.0 eV)")
    print("=" * 65)

    energies = np.linspace(1.5, 5.0, 300)
    d_perp = feibelman_d_perp(energies)
    d_par  = feibelman_d_parallel(energies)

    out_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'processed')
    os.makedirs(out_dir, exist_ok=True)
    out_file = os.path.join(out_dir, 'tddft_feibelman_parameters_300pts.csv')

    with open(out_file, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['energy_eV', 'd_perp_real_A', 'd_perp_imag_A', 'd_par_real_A', 'd_par_imag_A'])
        for i, E in enumerate(energies):
            w.writerow([f'{E:.4f}',
                        f'{np.real(d_perp[i]):.6f}', f'{np.imag(d_perp[i]):.6f}',
                        f'{np.real(d_par[i]):.6f}',  f'{np.imag(d_par[i]):.6f}'])

    print(f"[SUCCESS] Exported 300 TD-DFT Feibelman points to: {out_file}")

if __name__ == '__main__':
    export_tddft_parameters()
