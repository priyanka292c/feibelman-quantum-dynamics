"""
mesh_config.py
==============
Mesh and numerical grid configuration for nanophotonic simulations.
Strict standard:
  - Mesh size: 0.5 nm (dx = dy = dz = 0.5e-9 m) in the near-field override region
  - Data points: 300 frequency / wavelength sampling points
"""

# Spatial mesh resolution
MESH_SIZE_NM = 0.5          # 0.5 nm mesh size
MESH_SIZE_M  = 0.5e-9       # in meters

# Frequency monitor resolution
DATA_POINTS  = 300          # 300 frequency/wavelength monitor data points

# Simulation region boundaries
SIM_X_SPAN = 200e-9         # 200 nm
SIM_Y_SPAN = 200e-9         # 200 nm
SIM_Z_SPAN = 300e-9         # 300 nm

# Mesh override zone (interface layer)
OVERRIDE_X_SPAN = 80e-9
OVERRIDE_Y_SPAN = 80e-9
OVERRIDE_Z_MIN  = -5e-9     # 5 nm inside metal
OVERRIDE_Z_MAX  = 15e-9     # 15 nm in vacuum

# Spectral window
LAMBDA_MIN_NM = 275.0       # ~4.5 eV
LAMBDA_MAX_NM = 688.0       # ~1.8 eV
