"""
reproduce_fig5.py
=================
Reproduces Figure 5: Perpendicular and total LDOS spectra (Au interface, z = 5 nm).
"""

import sys, os
PKG_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
WORKSPACE = os.path.abspath(os.path.join(PKG_ROOT, '..'))
sys.path.insert(0, os.path.join(WORKSPACE, 'code', 'plotting'))
import generate_figures

if __name__ == '__main__':
    print("Reproducing Figure 5: LDOS spectra...")
    generate_figures.figure5_ldos_spectra()
    print("Figure 5 reproduced successfully.")
