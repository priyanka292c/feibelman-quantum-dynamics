"""
reproduce_fig4.py
=================
Reproduces Figure 4: Numerical convergence analysis (quadrature and distance sampling).
"""

import sys, os
PKG_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
WORKSPACE = os.path.abspath(os.path.join(PKG_ROOT, '..'))
sys.path.insert(0, os.path.join(WORKSPACE, 'code', 'plotting'))
import generate_figures

if __name__ == '__main__':
    print("Reproducing Figure 4: Numerical convergence...")
    generate_figures.figure4_convergence()
    print("Figure 4 reproduced successfully.")
