"""
reproduce_fig3.py
=================
Reproduces Figure 3 of the manuscript:
"Feibelman-Corrected Green-Function Modeling of Quantum Emitters Near Planar Gold Interfaces"
Target Journal: Computational Materials Today (Elsevier)
"""

import sys, os
PKG_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
WORKSPACE = os.path.abspath(os.path.join(PKG_ROOT, '..'))
sys.path.insert(0, os.path.join(WORKSPACE, 'code', 'plotting'))
import generate_figures

if __name__ == '__main__':
    print("Reproducing Figure 3: Nanophotonic geometry & simulation domain...")
    generate_figures.figure3_geometry_setup()
    print("Figure 3 reproduced successfully.")
