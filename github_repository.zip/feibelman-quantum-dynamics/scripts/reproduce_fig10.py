"""
reproduce_fig10.py
==================
Reproduces Figure 10: Sensitivity analysis and parameter uncertainty propagation.
"""

import sys, os
PKG_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
WORKSPACE = os.path.abspath(os.path.join(PKG_ROOT, '..'))
sys.path.insert(0, os.path.join(WORKSPACE, 'code', 'plotting'))
import generate_figures

if __name__ == '__main__':
    print("Reproducing Figure 10: Sensitivity and uncertainty analysis...")
    generate_figures.figure10_sensitivity()
    print("Figure 10 reproduced successfully.")
