"""
reproduce_fig9.py
=================
Reproduces Figure 9: Direct comparison between Local Drude, Hydrodynamic, and Feibelman models.
"""

import sys, os
PKG_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
WORKSPACE = os.path.abspath(os.path.join(PKG_ROOT, '..'))
sys.path.insert(0, os.path.join(WORKSPACE, 'code', 'plotting'))
import generate_figures

if __name__ == '__main__':
    print("Reproducing Figure 9: Model comparison...")
    generate_figures.figure9_model_comparison()
    print("Figure 9 reproduced successfully.")
