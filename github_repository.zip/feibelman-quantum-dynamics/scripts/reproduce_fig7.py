"""
reproduce_fig7.py
=================
Reproduces Figure 7: 2D parameter-space contour map of Purcell factor and Feibelman corrections.
"""

import sys, os
PKG_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
WORKSPACE = os.path.abspath(os.path.join(PKG_ROOT, '..'))
sys.path.insert(0, os.path.join(WORKSPACE, 'code', 'plotting'))
import generate_figures

if __name__ == '__main__':
    print("Reproducing Figure 7: Parameter-space map...")
    generate_figures.figure7_parameter_map()
    print("Figure 7 reproduced successfully.")
