"""
reproduce_fig11.py
==================
Reproduces Figure 11: Two-qubit open quantum system dynamics and concurrence.
"""

import sys, os
PKG_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
WORKSPACE = os.path.abspath(os.path.join(PKG_ROOT, '..'))
sys.path.insert(0, os.path.join(WORKSPACE, 'code', 'plotting'))
import generate_figures

if __name__ == '__main__':
    print("Reproducing Figure 11: Two-qubit quantum dynamics...")
    generate_figures.figure11_quantum_dynamics()
    print("Figure 11 reproduced successfully.")
