"""
reproduce_fig8.py
=================
Reproduces Figure 8: Au vs. Cu material comparison.
"""

import sys, os
PKG_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
WORKSPACE = os.path.abspath(os.path.join(PKG_ROOT, '..'))
sys.path.insert(0, os.path.join(WORKSPACE, 'code', 'plotting'))
import generate_figures

if __name__ == '__main__':
    print("Reproducing Figure 8: Au vs. Cu comparison...")
    generate_figures.figure8_au_vs_cu()
    print("Figure 8 reproduced successfully.")
