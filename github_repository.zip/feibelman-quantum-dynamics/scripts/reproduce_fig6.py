"""
reproduce_fig6.py
=================
Reproduces Figure 6: Purcell factor vs. emitter-surface distance z (0.5 to 20 nm).
"""

import sys, os
PKG_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
WORKSPACE = os.path.abspath(os.path.join(PKG_ROOT, '..'))
sys.path.insert(0, os.path.join(WORKSPACE, 'code', 'plotting'))
import generate_figures

if __name__ == '__main__':
    print("Reproducing Figure 6: Purcell factor vs. distance...")
    generate_figures.figure6_purcell_vs_distance()
    print("Figure 6 reproduced successfully.")
