# feibelman-quantum-dynamics

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python: 3.12](https://img.shields.io/badge/python-3.12-blue.svg)](https://www.python.org/downloads/)
[![Target Journal: Computational Materials Today](https://img.shields.io/badge/Elsevier-Computational_Materials_Today-green.svg)](https://www.sciencedirect.com/journal/computational-materials-today)

Open-source multiscale computational framework connecting literature-derived Au(111) Feibelman surface-response parameters to generalized boundary conditions, Sommerfeld dyadic Green tensors, Purcell enhancement factors, and two-qubit open quantum dynamics.

---

## Authors
- **Priyanka Sharma** (IIT Roorkee)
- **Rajesh Kumar** (IISc Bangalore)
- **Vikramaditya Singh** (IIT Bombay)

Target Journal: *Computational Materials Today* (Elsevier)

---

## Directory Structure
```
feibelman-quantum-dynamics/
├── README.md
├── LICENSE
├── environment.yml
├── requirements.txt
├── CITATION.cff
│
├── data/
│   ├── feibelman_Au111/
│   │   └── feibelman_parameters_Au111.csv
│   ├── material_parameters/
│   │   └── material_database.csv
│   └── processed_results/
│       └── [tabulated CSV/NPZ simulation outputs]
│
├── processed_results/
│   ├── fig2_material_properties.csv
│   ├── fig4_convergence.csv
│   ├── fig5_ldos_spectra.csv
│   ├── fig6_purcell_distance.csv
│   ├── fig7_parameter_map.npz
│   ├── fig8_au_vs_cu.csv
│   ├── fig9_model_comparison.csv
│   ├── fig10_sensitivity.csv
│   └── fig11_quantum_dynamics.csv
│
├── src/
│   ├── __init__.py
│   ├── materials.py
│   ├── feibelman.py
│   ├── fresnel.py
│   ├── green_tensor.py
│   ├── purcell.py
│   └── quantum_dynamics.py
│
├── scripts/
│   ├── reproduce_fig3.py
│   ├── reproduce_fig4.py
│   ├── reproduce_fig5.py
│   ├── reproduce_fig6.py
│   ├── reproduce_fig7.py
│   ├── reproduce_fig8.py
│   ├── reproduce_fig9.py
│   ├── reproduce_fig10.py
│   └── reproduce_fig11.py
│
└── tests/
    ├── __init__.py
    ├── test_fresnel.py
    ├── test_green_tensor.py
    ├── test_kossakowski.py
    └── test_convergence.py
```

---

## Installation & Environment

### Option A: Using Conda (Recommended)
```bash
conda env create -f environment.yml
conda activate feibelman-quantum-dynamics
```

### Option B: Using Pip
```bash
pip install -r requirements.txt
```

### Verified Computational Environment
- **Operating Systems**: Windows 11 Enterprise (build 22631) and Ubuntu Linux 22.04 LTS (x86_64)
- **Python**: 3.12.10
- **NumPy**: 2.5.1
- **SciPy**: 1.18.0
- **QuTiP**: 5.3.1
- **Matplotlib**: 3.11.0
- **Pytest**: 9.1.1

---

## Running Unit Tests
To verify all physical reflection limits, Green-tensor reciprocity, complete positivity, and numerical convergence:
```bash
pytest tests/
```
All 10 test suites should pass cleanly in $< 5$\,s.

---

## Reproducing Manuscript Figures
Run any individual figure script:
```bash
python scripts/reproduce_fig3.py   # Geometry & simulation domain
python scripts/reproduce_fig4.py   # Numerical convergence (quadrature & mesh)
python scripts/reproduce_fig5.py   # LDOS spectra (Au interface, z = 5 nm)
python scripts/reproduce_fig6.py   # Purcell factor vs. distance
python scripts/reproduce_fig7.py   # Parameter-space map (contours of Delta F_P)
python scripts/reproduce_fig8.py   # Au vs. Cu comparison
python scripts/reproduce_fig9.py   # Local vs. Hydrodynamic vs. Feibelman models
python scripts/reproduce_fig10.py  # Sensitivity & parameter uncertainty
python scripts/reproduce_fig11.py  # Two-qubit quantum dynamics & concurrence
```

---

## Quantum Dynamics: Exact Kossakowski vs. Partitioned Model

The two-qubit dissipative coupling is governed by the 2x2 Kossakowski decay matrix:
$$\mathbf{\Gamma} = \begin{pmatrix} \Gamma_1 & \Gamma_{12} \\ \Gamma_{12} & \Gamma_2 \end{pmatrix}$$

### 1. Primary Physical Result: Exact Kossakowski Diagonalization
The decay matrix is diagonalized $\mathbf{\Gamma} = \mathbf{V}\mathbf{\Lambda}\mathbf{V}^\dagger$ with non-negative normal-mode eigenvalues $\lambda_\pm = \Gamma_1 \pm |\Gamma_{12}| \ge 0$. The exact Lindblad jump operators are:
$$C_\pm = \sqrt{\frac{\lambda_\pm}{2}} (\sigma_{-,1} \pm \mathrm{sgn}(\Gamma_{12})\sigma_{-,2})$$
This mathematically rigorous representation yields:
- Peak Concurrence: $C_{\max} \approx 0.696$ (Feibelman) / $0.693$ (Local)
- Entanglement Lifetime ($\mathcal{C}(t) \ge 0.10$): $\tau_{\mathcal{C}} \approx 0.264\,\gamma_0^{-1}$ (Feibelman) / $0.268\,\gamma_0^{-1}$ (Local)

### 2. Secondary Comparison Model: Partitioned Collapse Channels
A heuristic representation using independent decays $C_1 = \sqrt{\Gamma_1}\sigma_{-,1}$, $C_2 = \sqrt{\Gamma_2}\sigma_{-,2}$ and collective channel $C_{\mathrm{coll}} = \sqrt{|\Gamma_{12}|/2}(\sigma_{-,1} + \mathrm{sgn}(\Gamma_{12})\sigma_{-,2})$ yields an effective decay matrix:
$$\mathbf{\Gamma}_{\mathrm{eff}} = \begin{pmatrix} \Gamma_1 + \frac{1}{2}|\Gamma_{12}| & \frac{1}{2}\Gamma_{12} \\ \frac{1}{2}\Gamma_{12} & \Gamma_2 + \frac{1}{2}|\Gamma_{12}| \end{pmatrix} \neq \mathbf{\Gamma}$$
This over-damps the single-emitter channels and under-weights cross-talk, leading to an artificially reduced concurrence lifetime:
- Peak Concurrence: $C_{\max} \approx 0.571$ (Feibelman) / $0.569$ (Local)
- Entanglement Lifetime: $\tau_{\mathcal{C}} \approx 0.038\,\gamma_0^{-1}$ (Feibelman) / $0.038\,\gamma_0^{-1}$ (Local)

---

## Citation & License
This codebase is released under the **MIT License**. If you find this framework useful, please cite it using the metadata in `CITATION.cff`.
