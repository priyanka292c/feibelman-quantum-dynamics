"""
green_tensor.py
===============
Sommerfeld integration and dyadic Green tensor calculations for planar interfaces.

Features:
  - Exact Sommerfeld integrals for self-interaction scattering dyadic G_scat(r1, r1, omega)
  - Full dyadic cross Green tensor G(r1, r2, omega) = G0(r1, r2, omega) + G_scat(r1, r2, omega)
  - Direct calculation of coherent exchange g_12 and collective dissipative coupling Gamma_12
  - Completely positive decay matrices and Kossakowski parameters.

References:
  - Novotny & Hecht, Principles of Nano-Optics, Cambridge University Press (2012).
  - Dung, Knoll, & Welsch, Phys. Rev. A 62, 053804 (2000). DOI: 10.1103/PhysRevA.62.053804
  - Ford & Weber, Phys. Rep. 113, 195 (1984). DOI: 10.1016/0370-1573(84)90098-X
"""

import numpy as np
from scipy.special import j0, jn
from .materials import c0, eps0, hbar, eV, eV_to_omega, eps_Au_drude, eps_Cu_drude
from .feibelman import feibelman_d_perp, feibelman_d_parallel
from .fresnel import kz_medium, rp_local, rs_local, rp_feibelman, rs_feibelman, rp_hydrodynamic


def _integrand_full(u, omega, z, eps_m, model='local',
                    d_perp_A=None, d_par_A=None, beta_TF=None):
    """
    Integrand for perpendicular and parallel dipole orientations above planar interface.
    Ford & Weber, Phys. Rep. 113, 195 (1984).
    """
    k0    = omega / c0
    k_par = u * k0
    kz1   = kz_medium(k_par, omega, 1.0)
    phase = np.exp(2j * kz1 * z)

    if model == 'local':
        rp_val = rp_local(k_par, omega, 1.0, eps_m)
        rs_val = rs_local(k_par, omega, 1.0, eps_m)
    elif model == 'feibelman':
        rp_val = rp_feibelman(k_par, omega, eps_m, d_perp_A, d_par_A)
        rs_val = rs_feibelman(k_par, omega, eps_m, d_perp_A, d_par_A)
    elif model == 'hydrodynamic':
        rp_val = rp_hydrodynamic(k_par, omega, eps_m, beta_TF)
        rs_val = rs_local(k_par, omega, 1.0, eps_m)
    else:
        raise ValueError(f"Unknown model: {model}")

    integrand_p_perp = np.real(u**3 / kz1 * rp_val * phase) * k0
    integrand_p_par  = np.real(u / kz1 * rp_val * (kz1 / k0)**2 * phase) * k0
    integrand_s_par  = np.real(u / kz1 * rs_val * phase) * k0

    return integrand_p_par, integrand_s_par, integrand_p_perp


def compute_ldos(omega, z_m, eps_m, model='local',
                 d_perp_A=None, d_par_A=None, beta_TF=None,
                 u_max=6.0, n_quad=300):
    """
    Compute normalized LDOS (Purcell factor) for an emitter at distance z_m.
    """
    us = np.linspace(1e-6, u_max, n_quad)
    int_p_par, int_s_par, int_p_perp = _integrand_full(
        us, omega, z_m, eps_m, model,
        d_perp_A, d_par_A, beta_TF)

    I_p_par  = np.trapezoid(int_p_par,  us)
    I_s_par  = np.trapezoid(int_s_par,  us)
    I_p_perp = np.trapezoid(int_p_perp, us)

    ldos_perp  = 1.0 + 1.5 * I_p_perp
    ldos_par   = 1.0 + 0.75 * (I_p_par + I_s_par)
    ldos_total = (ldos_perp + 2.0 * ldos_par) / 3.0

    return {
        'ldos_perp':    float(ldos_perp),
        'ldos_par':     float(ldos_par),
        'ldos_total':   float(ldos_total),
        'purcell_perp': float(ldos_perp),
        'model':        model,
        'omega':        omega,
        'z_m':          z_m
    }


def compute_cross_green_tensor(omega, z1, z2, R12, eps_m, model='local',
                               d_perp_A=None, d_par_A=None, beta_TF=None,
                               orientation='zz', u_max=6.0, n_quad=500):
    """
    Compute full Dyadic Green Tensor between two emitters at r1=(0,0,z1) and r2=(R12,0,z2).
    G(r1, r2, omega) = G_0(r1, r2, omega) + G_scat(r1, r2, omega)

    Extracts:
      Gamma_11 / gamma0 = 1 + (6*pi/k0) * Im[G_zz^scat(r1, r1, omega)]
      Gamma_22 / gamma0 = 1 + (6*pi/k0) * Im[G_zz^scat(r2, r2, omega)]
      Gamma_12 / gamma0 = (6*pi/k0) * Im[G_zz(r1, r2, omega)]
      g_12     / gamma0 = (3*pi/k0) * Re[G_zz(r1, r2, omega)]
    """
    k0 = omega / c0
    norm = 6.0 * np.pi / k0

    # 1. Direct free-space Green tensor component
    if R12 < 1e-15:
        G0 = 1j * k0 / (6.0 * np.pi)
    else:
        k0R = k0 * R12
        if orientation == 'zz':
            G0 = (np.exp(1j * k0R) / (4.0 * np.pi * R12)) * (1.0 + 1j / k0R - 1.0 / (k0R**2))
        else:
            G0 = (np.exp(1j * k0R) / (4.0 * np.pi * R12)) * (-2.0j / k0R + 2.0 / (k0R**2))

    if model == 'free':
        Gamma11 = 1.0
        Gamma22 = 1.0
        Gamma12 = float(norm * np.imag(G0))
        g12     = float((norm / 2.0) * np.real(G0))
        return {
            'Gamma11': Gamma11, 'Gamma22': Gamma22,
            'Gamma12': Gamma12, 'g12': g12,
            'G_total': G0, 'G_scat': 0.0 + 0j, 'G_0': G0
        }

    # 2. Scattered Green tensor via Sommerfeld integration
    us = np.linspace(1e-6, u_max, n_quad)
    qs = us * k0
    vals_cross = []
    vals_self1 = []
    vals_self2 = []

    for u, q in zip(us, qs):
        kz1 = kz_medium(q, omega, 1.0)

        if model == 'local':
            rp_val = rp_local(q, omega, 1.0, eps_m)
            rs_val = rs_local(q, omega, 1.0, eps_m)
        elif model == 'feibelman':
            rp_val = rp_feibelman(q, omega, eps_m, d_perp_A, d_par_A)
            rs_val = rs_feibelman(q, omega, eps_m, d_perp_A, d_par_A)
        elif model == 'hydrodynamic':
            rp_val = rp_hydrodynamic(q, omega, eps_m, beta_TF)
            rs_val = rs_local(q, omega, 1.0, eps_m)
        else:
            raise ValueError(f"Unknown model: {model}")

        phase_cross = np.exp(1j * kz1 * (z1 + z2))
        phase_self1 = np.exp(2j * kz1 * z1)
        phase_self2 = np.exp(2j * kz1 * z2)

        if orientation == 'zz':
            kernel = (q**3 / (kz1 * k0**2)) * rp_val
            int_cross = kernel * j0(q * R12) * phase_cross
            int_self1 = kernel * phase_self1
            int_self2 = kernel * phase_self2
        else:
            kernel_p = (q * kz1 / k0**2) * rp_val
            kernel_s = (q / kz1) * rs_val
            j0_term = 0.5 * (j0(q * R12) - jn(2, q * R12))
            int_cross = (kernel_p * j0_term + kernel_s * 0.5 * (j0(q * R12) + jn(2, q * R12))) * phase_cross
            int_self1 = 0.5 * (kernel_p + kernel_s) * phase_self1
            int_self2 = 0.5 * (kernel_p + kernel_s) * phase_self2

        vals_cross.append(int_cross)
        vals_self1.append(int_self1)
        vals_self2.append(int_self2)

    G_scat_cross = (1j / (4.0 * np.pi)) * np.trapezoid(vals_cross, qs)
    G_scat_self1 = (1j / (4.0 * np.pi)) * np.trapezoid(vals_self1, qs)
    G_scat_self2 = (1j / (4.0 * np.pi)) * np.trapezoid(vals_self2, qs)

    G_tot_cross = G0 + G_scat_cross

    Gamma11 = float(1.0 + norm * np.imag(G_scat_self1))
    Gamma22 = float(1.0 + norm * np.imag(G_scat_self2))
    Gamma12 = float(norm * np.imag(G_tot_cross))
    g12     = float((norm / 2.0) * np.real(G_tot_cross))

    return {
        'Gamma11': Gamma11,
        'Gamma22': Gamma22,
        'Gamma12': Gamma12,
        'g12':     g12,
        'G_total': G_tot_cross,
        'G_scat':  G_scat_cross,
        'G_0':     G0
    }
