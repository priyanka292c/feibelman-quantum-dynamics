"""
quantum_dynamics.py
===================
Two-qubit open quantum system dynamics driven by Dyadic Green Tensor coupling.

Mathematical Formulations:
  1. Exact Kossakowski Diagonalization (Primary Physical Result):
     Diagonalizes the 2x2 Kossakowski decay matrix:
       Gamma = V Lambda V^dagger, with eigenvalues lambda_k >= 0.
     Constructs non-heuristic jump operators:
       C_k = sqrt(lambda_k) * sum_j V_{jk} sigma_{-,j}
     Guarantees complete positivity and trace preservation (CPTP).

  2. Partitioned Collapse Channels (Secondary Numerical Comparison):
     Assigns independent single-qubit decays plus a collective channel:
       C_1 = sqrt(Gamma_1) sigma_{-,1}
       C_2 = sqrt(Gamma_2) sigma_{-,2}
       C_coll = sqrt(|Gamma_12|/2) * (sigma_{-,1} + sgn(Gamma_12) * sigma_{-,2})
     Note: This heuristic scheme yields an effective decay matrix:
       Gamma_eff = [[Gamma_1 + |Gamma_12|/2,  Gamma_12/2],
                    [Gamma_12/2,              Gamma_2 + |Gamma_12|/2]] != Gamma
     which causes artificial single-emitter over-damping and suppresses entanglement lifetime.

References:
  - Kossakowski, Rep. Math. Phys. 3, 247-274 (1972).
  - Lindblad, Commun. Math. Phys. 48, 119-130 (1976).
  - Breuer & Petruccione, The Theory of Open Quantum Systems, Oxford (2002).
  - Wootters, Phys. Rev. Lett. 80, 2245 (1998). DOI: 10.1103/PhysRevLett.80.2245
"""

import numpy as np
import qutip as qt
from .materials import hbar, eV


def build_two_qubit_operators():
    """
    Build fundamental single-qubit operators in the two-qubit Hilbert space.
    |g> = |0>, |e> = |1>
    """
    g = qt.basis(2, 0)   # ground
    e = qt.basis(2, 1)   # excited

    sigma_plus_1  = qt.tensor(e * g.dag(), qt.qeye(2))
    sigma_minus_1 = qt.tensor(g * e.dag(), qt.qeye(2))
    sigma_z_1     = qt.tensor(qt.sigmaz(), qt.qeye(2))
    sigma_plus_2  = qt.tensor(qt.qeye(2), e * g.dag())
    sigma_minus_2 = qt.tensor(qt.qeye(2), g * e.dag())
    sigma_z_2     = qt.tensor(qt.qeye(2), qt.sigmaz())

    return {
        'sp1': sigma_plus_1, 'sm1': sigma_minus_1, 'sz1': sigma_z_1,
        'sp2': sigma_plus_2, 'sm2': sigma_minus_2, 'sz2': sigma_z_2,
        'g': g, 'e': e
    }


def analyze_kossakowski_matrix(Gamma1, Gamma2, Gamma12):
    """
    Construct and audit the Kossakowski decay matrix:
      Gamma = [[Gamma1,  Gamma12],
               [Gamma12, Gamma2 ]]
    Verifies complete positivity (lambda_min >= 0) per the Kossakowski-Lindblad theorem.
    """
    Gamma_mat = np.array([[Gamma1, Gamma12], [Gamma12, Gamma2]], dtype=float)
    eigenvals, eigenvecs = np.linalg.eigh(Gamma_mat)
    min_eig = float(np.min(eigenvals))
    is_psd = bool(min_eig >= -1e-10)
    return {
        'matrix': Gamma_mat,
        'eigenvalues': eigenvals,
        'lambda_minus': float(eigenvals[0]),
        'lambda_plus':  float(eigenvals[1]),
        'min_eigenvalue': min_eig,
        'eigenvectors': eigenvecs,
        'is_positive_semidefinite': is_psd
    }


def kossakowski_eigenvalues(Gamma1, Gamma2, Gamma12):
    """Return analytical/numerical eigenvalues of the 2x2 Kossakowski decay matrix."""
    audit = analyze_kossakowski_matrix(Gamma1, Gamma2, Gamma12)
    return audit['lambda_minus'], audit['lambda_plus']


def build_lindblad_system(omega_q, rates, ops, dephasing=0.0, method='diagonal'):
    """
    Construct Hamiltonian and collapse operators for two-qubit Lindblad equation.

    Parameters
    ----------
    omega_q  : float, qubit transition frequency (normalized)
    rates    : dict with Gamma1, Gamma2, Gamma12, g12
    ops      : dict from build_two_qubit_operators()
    dephasing: float, pure dephasing rate
    method   : str, 'diagonal' (exact Kossakowski eigensystem) or 'partitioned'

    Returns
    -------
    H : Qobj, total Hamiltonian
    c_ops : list of Qobj, collapse operators
    kossakowski_audit : dict of eigenvalue and positivity metrics
    """
    sp1, sm1 = ops['sp1'], ops['sm1']
    sp2, sm2 = ops['sp2'], ops['sm2']
    sz1, sz2 = ops['sz1'], ops['sz2']

    Gamma1  = rates.get('Gamma1', rates.get('Gamma11', 1.0))
    Gamma2  = rates.get('Gamma2', rates.get('Gamma22', 1.0))
    Gamma12 = rates['Gamma12']
    g12     = rates['g12']

    audit = analyze_kossakowski_matrix(Gamma1, Gamma2, Gamma12)

    # Hamiltonian: H = (omega_q/2)(sz1 + sz2) + g12(sp1 sm2 + sp2 sm1)
    H = (omega_q / 2.0) * (sz1 + sz2) + g12 * (sp1 * sm2 + sp2 * sm1)

    if method == 'diagonal':
        # Primary physical representation: exact diagonalized Kossakowski jump operators
        c_ops = []
        for k in range(2):
            lam_k = max(0.0, audit['eigenvalues'][k])
            v = audit['eigenvectors'][:, k]
            op_k = np.sqrt(lam_k) * (v[0] * sm1 + v[1] * sm2)
            c_ops.append(op_k)
    else:
        # Secondary comparison representation: partitioned heuristic channels
        c1 = np.sqrt(Gamma1) * sm1
        c2 = np.sqrt(Gamma2) * sm2
        c_coll = np.sqrt(abs(Gamma12) / 2.0) * (sm1 + np.sign(Gamma12) * sm2)
        c_ops = [c1, c2, c_coll]

    if dephasing > 0:
        c_deph1 = np.sqrt(dephasing / 2.0) * sz1
        c_deph2 = np.sqrt(dephasing / 2.0) * sz2
        c_ops += [c_deph1, c_deph2]

    return H, c_ops, audit


def concurrence(rho):
    """
    Evaluate Wootters concurrence for two-qubit density matrix rho.
    Reference: Wootters, Phys. Rev. Lett. 80, 2245 (1998).
    """
    rho_mat = rho.full()

    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sysy = np.kron(sy, sy)
    rho_tilde = sysy @ rho_mat.conj() @ sysy

    vals, vecs = np.linalg.eigh(rho_mat)
    vals_clipped = np.maximum(vals, 0.0)
    sqrt_rho = vecs @ np.diag(np.sqrt(vals_clipped)) @ vecs.conj().T

    R = sqrt_rho @ rho_tilde @ sqrt_rho

    R_vals = np.linalg.eigvals(R)
    sqrt_R_vals = np.sqrt(np.maximum(np.real(R_vals), 0.0))
    sqrt_R_vals_sorted = np.sort(sqrt_R_vals)[::-1]

    C = max(0.0, sqrt_R_vals_sorted[0] - sqrt_R_vals_sorted[1]
                 - sqrt_R_vals_sorted[2] - sqrt_R_vals_sorted[3])
    return float(C)


def calculate_concurrence(rho):
    """Alias for concurrence function."""
    return concurrence(rho)


def validate_density_matrix(rho):
    """Verify trace preservation, Hermiticity, and positive semidefiniteness."""
    tr = rho.tr()
    eigenvals = rho.eigenenergies()
    herm_err = (rho - rho.dag()).norm()

    return {
        'trace': float(np.real(tr)),
        'trace_ok': abs(np.real(tr) - 1.0) < 1e-6,
        'hermitian_err': float(herm_err),
        'hermitian_ok': herm_err < 1e-6,
        'min_eigenval': float(np.min(eigenvals)),
        'positive_ok': float(np.min(eigenvals)) > -1e-8
    }


def run_dynamics(rates, omega_q=10.0, gamma0=1.0, t_max=1.0, n_t=300,
                 dephasing=0.0, initial_state='excited_1', method='diagonal'):
    """
    Execute two-qubit Lindblad time propagation.

    Parameters
    ----------
    rates : dict with Gamma1, Gamma2, Gamma12, g12
    omega_q : float, qubit transition energy
    gamma0 : float, free space decay rate
    t_max : float, duration in units of 1/gamma0
    n_t : int, time grid resolution
    initial_state : str, 'excited_1' | 'excited_both' | 'bell'
    method : str, 'diagonal' | 'partitioned'
    """
    ops = build_two_qubit_operators()
    H, c_ops, audit = build_lindblad_system(omega_q, rates, ops, dephasing, method=method)

    g = ops['g']
    e = ops['e']
    if initial_state == 'excited_1':
        psi0 = qt.tensor(e, g)
    elif initial_state == 'excited_both':
        psi0 = qt.tensor(e, e)
    elif initial_state == 'bell':
        psi0 = (qt.tensor(e, g) + qt.tensor(g, e)).unit()
    else:
        psi0 = qt.tensor(e, g)

    rho0 = psi0 * psi0.dag()
    tlist = np.linspace(0, t_max / gamma0, n_t)

    sm1, sm2 = ops['sm1'], ops['sm2']
    sp1, sp2 = ops['sp1'], ops['sp2']
    e_pop_1 = sp1 * sm1
    e_pop_2 = sp2 * sm2

    qutip_opts = {'nsteps': 5000, 'rtol': 1e-8, 'atol': 1e-10}
    result = qt.mesolve(H, rho0, tlist, c_ops, e_ops=[e_pop_1, e_pop_2], options=qutip_opts)
    result_full = qt.mesolve(H, rho0, tlist, c_ops, e_ops=[], options=qutip_opts)

    concurrence_t = np.array([concurrence(rho) for rho in result_full.states])
    c_max = float(np.max(concurrence_t))
    t_max_conc = float(tlist[np.argmax(concurrence_t)])

    c_thresh = 0.10
    idx_above = np.where(concurrence_t >= c_thresh)[0]
    tau_C = float(tlist[idx_above[-1]]) if len(idx_above) > 0 else 0.0

    rho_final = result_full.states[-1]
    validation = validate_density_matrix(rho_final)

    return {
        'tlist':         tlist,
        'pop1':          result.expect[0],
        'pop2':          result.expect[1],
        'concurrence':   concurrence_t,
        'c_max':         c_max,
        't_max':         t_max_conc,
        'tau_C':         tau_C,
        'kossakowski':   audit,
        'rho_final':     rho_final,
        'validation':    validation,
        'rates':         rates,
        'H':             H,
        'method':        method
    }


def solve_exact_kossakowski(rates, omega_q=10.0, gamma0=1.0, t_max=1.0, n_t=300):
    """Execute primary physical simulation using exact Kossakowski diagonalization."""
    return run_dynamics(rates, omega_q=omega_q, gamma0=gamma0, t_max=t_max, n_t=n_t, method='diagonal')


def solve_partitioned(rates, omega_q=10.0, gamma0=1.0, t_max=1.0, n_t=300):
    """Execute secondary numerical comparison using partitioned collapse channels."""
    return run_dynamics(rates, omega_q=omega_q, gamma0=gamma0, t_max=t_max, n_t=n_t, method='partitioned')
