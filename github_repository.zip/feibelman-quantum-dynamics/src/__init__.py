"""
feibelman-quantum-dynamics
==========================
Open-source multiscale computational framework connecting literature-derived
Au(111) Feibelman surface response parameters to planar dyadic Green tensors,
Purcell enhancement factors, and two-qubit open quantum dynamics.

Target Publication: Computational Materials Today (Elsevier)
Authors: Priyanka Sharma, Rajesh Kumar, Vikramaditya Singh
"""

__version__ = "1.0.0"
__author__ = "Priyanka Sharma, Rajesh Kumar, Vikramaditya Singh"

from .materials import eps_Au_drude, eps_Cu_drude, eV_to_omega, omega_to_eV
from .feibelman import feibelman_d_perp, feibelman_d_parallel
from .fresnel import rp_local, rs_local, rp_hydrodynamic, rp_feibelman, rs_feibelman
from .green_tensor import compute_ldos, compute_cross_green_tensor, kz_medium
from .purcell import compute_purcell_factor, purcell_spectrum, purcell_distance_sweep
from .quantum_dynamics import (
    solve_exact_kossakowski,
    solve_partitioned,
    calculate_concurrence,
    kossakowski_eigenvalues
)
