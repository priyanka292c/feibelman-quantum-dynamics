"""
fresnel.py
==========
Fresnel reflection coefficients for planar interfaces across electrodynamic models:
  1. Local classical model (sharp dielectric-metal interface)
  2. Hydrodynamic nonlocal model (Thomas-Fermi pressure, hard-wall ABC)
  3. Feibelman generalized boundary condition (GBC) model

References:
  - Local model: Novotny & Hecht, Principles of Nano-Optics, Cambridge (2012).
  - Hydrodynamic: Toscano et al., Nat. Commun. 6, 7132 (2015).
  - Feibelman GBC: Yang et al., Nature 576, 248 (2019); Yang et al., PRB 100, 035406 (2019);
                   Gonçalves et al., Nat. Commun. 11, 366 (2020).
"""

import numpy as np
from .materials import c0, eV, hbar


def kz_medium(k_par, omega, eps):
    """
    z-component of wavevector in medium with relative permittivity eps:
      kz = sqrt(eps * (omega/c)^2 - k_par^2)
    Branch cut choice: Im[kz] >= 0 (outgoing / evanescent decaying into z > 0).
    """
    k0 = omega / c0
    kz2 = eps * k0**2 - k_par**2
    kz = np.sqrt(kz2 + 0j)
    kz = np.where(np.imag(kz) < 0, -kz, kz)
    return kz


def rp_local(k_par, omega, eps1=1.0, eps2=None):
    """
    p-polarization (TM) Fresnel reflection coefficient for local classical model.
    """
    kz1 = kz_medium(k_par, omega, eps1)
    kz2 = kz_medium(k_par, omega, eps2)
    return (eps2 * kz1 - eps1 * kz2) / (eps2 * kz1 + eps1 * kz2)


def rs_local(k_par, omega, eps1=1.0, eps2=None):
    """
    s-polarization (TE) Fresnel reflection coefficient for local classical model.
    """
    kz1 = kz_medium(k_par, omega, eps1)
    kz2 = kz_medium(k_par, omega, eps2)
    return (kz1 - kz2) / (kz1 + kz2)


def rp_feibelman(k_par, omega, eps_m, d_perp_A, d_par_A):
    """
    p-polarization Fresnel reflection coefficient with Feibelman surface response
    under Generalized Boundary Conditions (GBC):
      delta_num = (eps2 - eps1) * [i * k_par^2 * d_perp - (-i * kz1 * kz2 * d_par)]
      delta_den = (eps2 - eps1) * [i * k_par^2 * d_perp + (-i * kz1 * kz2 * d_par)]

    Dimension check:
      k_par^2 * d_perp has dimension m^-2 * m = m^-1
      kz1 * kz2 * d_par has dimension m^-1 * m^-1 * m = m^-1
      Both add dimensionally consistently to eps * kz (m^-1).
    """
    eps1 = 1.0  # vacuum
    eps2 = eps_m
    kz1 = kz_medium(k_par, omega, eps1)
    kz2 = kz_medium(k_par, omega, eps2)

    d_perp = d_perp_A * 1e-10   # Angstrom -> meters
    d_par  = d_par_A  * 1e-10

    term_perp = 1j * (k_par**2) * d_perp
    term_par  = -1j * kz1 * kz2 * d_par

    delta_num = (eps2 - eps1) * (term_perp - term_par)
    delta_den = (eps2 - eps1) * (term_perp + term_par)

    num   = eps2 * kz1 - eps1 * kz2 + delta_num
    denom = eps2 * kz1 + eps1 * kz2 - delta_den
    return num / denom


def rs_feibelman(k_par, omega, eps_m, d_perp_A, d_par_A):
    """
    s-polarization Fresnel reflection coefficient with Feibelman surface response.
    Ref: Yang et al., PRB 100, 035406 (2019), Eq. (13).
    """
    eps1 = 1.0
    eps2 = eps_m
    k0 = omega / c0
    kz1 = kz_medium(k_par, omega, eps1)
    kz2 = kz_medium(k_par, omega, eps2)
    d_par = d_par_A * 1e-10

    delta_s = (eps2 - eps1) * (k0**2) * d_par

    num   = kz1 - kz2 - delta_s
    denom = kz1 + kz2 + delta_s
    return num / denom


def rp_hydrodynamic(k_par, omega, eps_m, beta_TF=None):
    """
    p-polarization Fresnel reflection coefficient for hydrodynamic nonlocal model.
    Thomas-Fermi pressure velocity beta^2 = (3/5) * v_F^2.
    """
    if beta_TF is None:
        # Au Fermi velocity: v_F = 1.39e6 m/s
        beta_TF = 1.39e6 * np.sqrt(3.0 / 5.0)

    eps1 = 1.0
    eps2 = eps_m
    kz1 = kz_medium(k_par, omega, eps1)
    kz2 = kz_medium(k_par, omega, eps2)

    omega_p = 9.03 * eV / hbar
    kL2 = (omega**2 - omega_p**2 + 0j) / (beta_TF**2) + k_par**2
    kL  = np.sqrt(kL2 + 0j)
    kL  = np.where(np.imag(kL) < 0, -kL, kL)

    delta_HD = k_par**2 / (kL * eps2) if np.any(np.abs(kL) > 0) else 0.0

    num   = eps2 * kz1 - eps1 * kz2 + delta_HD
    denom = eps2 * kz1 + eps1 * kz2 + delta_HD
    return num / denom
