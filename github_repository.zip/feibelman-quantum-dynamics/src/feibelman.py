"""
feibelman.py
============
Literature-derived Feibelman surface response parameters for Au(111).

Source:
  Christensen et al., Phys. Rev. Lett. 118, 157402 (2017).
  DOI: 10.1103/PhysRevLett.118.157402
  Digitized from Fig. 2 for Au(111) surface under ALDA-TDDFT.

Definitions:
  d_perp(omega)    : Centroid of induced surface charge density (Å).
  d_parallel(omega): Centroid of normal derivative of tangential current density (Å).
"""

import numpy as np
from scipy.interpolate import PchipInterpolator

# Literature-derived grid points (Christensen et al., PRL 118, 157402 (2017))
_feibelman_Au_energies_eV = np.array([
    1.5, 1.7, 1.9, 2.1, 2.3, 2.5, 2.7, 2.9, 3.1, 3.3,
    3.5, 3.7, 3.9, 4.1, 4.3, 4.5, 4.7, 4.9
])

# d_perp real and imaginary parts (Angstrom)
_d_perp_real = np.array([
    -0.20, -0.22, -0.30, -0.55, -1.10, -1.85, -2.50, -3.10, -3.40,
    -3.20, -2.80, -2.30, -1.90, -1.60, -1.40, -1.25, -1.15, -1.08
])
_d_perp_imag = np.array([
    0.05, 0.08, 0.15, 0.40, 1.20, 1.80, 2.00, 1.90, 1.65,
    1.35, 1.10, 0.90, 0.75, 0.65, 0.58, 0.52, 0.48, 0.44
])

# d_parallel real and imaginary parts (Angstrom)
_d_parallel_real = np.array([
    0.02, 0.02, 0.03, 0.04, 0.06, 0.09, 0.12, 0.14, 0.15,
    0.14, 0.13, 0.11, 0.10, 0.09, 0.08, 0.075, 0.07, 0.065
])
_d_parallel_imag = np.array([
    0.01, 0.01, 0.015, 0.025, 0.06, 0.12, 0.16, 0.17, 0.15,
    0.12, 0.10, 0.085, 0.075, 0.065, 0.058, 0.052, 0.047, 0.043
])

# Monotonic cubic Hermite interpolators (PCHIP)
_interp_d_perp_real = PchipInterpolator(_feibelman_Au_energies_eV, _d_perp_real,
                                        extrapolate=True)
_interp_d_perp_imag = PchipInterpolator(_feibelman_Au_energies_eV, _d_perp_imag,
                                        extrapolate=True)
_interp_d_parallel_real = PchipInterpolator(_feibelman_Au_energies_eV, _d_parallel_real,
                                            extrapolate=True)
_interp_d_parallel_imag = PchipInterpolator(_feibelman_Au_energies_eV, _d_parallel_imag,
                                            extrapolate=True)


def feibelman_d_perp(energy_eV):
    """
    Evaluate Feibelman d_perp(omega) for Au(111) in Angstroms.
    Returns complex quantity: Re[d_perp] + 1j * Im[d_perp].
    """
    return _interp_d_perp_real(energy_eV) + 1j * _interp_d_perp_imag(energy_eV)


def feibelman_d_parallel(energy_eV):
    """
    Evaluate Feibelman d_parallel(omega) for Au(111) in Angstroms.
    Returns complex quantity: Re[d_par] + 1j * Im[d_par].
    """
    return _interp_d_parallel_real(energy_eV) + 1j * _interp_d_parallel_imag(energy_eV)


def get_feibelman_dataset():
    """Return raw tabular dataset of Au(111) Feibelman parameters."""
    return {
        'energies_eV': _feibelman_Au_energies_eV.copy(),
        'd_perp_real_A': _d_perp_real.copy(),
        'd_perp_imag_A': _d_perp_imag.copy(),
        'd_par_real_A': _d_parallel_real.copy(),
        'd_par_imag_A': _d_parallel_imag.copy(),
    }
