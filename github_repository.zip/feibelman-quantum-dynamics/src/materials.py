"""
materials.py
============
Validated bulk dielectric models for Gold (Au) and Copper (Cu).

Sources:
  - Gold (Au) & Copper (Cu) Drude-Lorentz fits:
    Rakić et al., Appl. Opt. 37, 5271-5283 (1998). DOI: 10.1364/AO.37.005271
  - Original experimental reference:
    Johnson & Christy, Phys. Rev. B 6, 4370-4379 (1972). DOI: 10.1103/PhysRevB.6.4370
"""

import numpy as np

# Physical fundamental constants (CODATA 2018)
hbar = 1.054571817e-34    # J*s (reduced Planck constant)
eV   = 1.602176634e-19    # J (electron volt)
c0   = 2.99792458e8       # m/s (speed of light in vacuum)
eps0 = 8.854187817e-12    # F/m (vacuum permittivity)
mu0  = 4.0 * np.pi * 1e-7 # H/m (vacuum permeability)


def omega_to_eV(omega):
    """Convert angular frequency (rad/s) to photon energy in eV."""
    return hbar * omega / eV


def eV_to_omega(energy_eV):
    """Convert photon energy in eV to angular frequency (rad/s)."""
    return energy_eV * eV / hbar


def wavelength_to_omega(lam_nm):
    """Convert wavelength in nm to angular frequency (rad/s)."""
    return 2.0 * np.pi * c0 / (lam_nm * 1e-9)


def eps_Au_drude(omega):
    """
    Gold (Au) Drude-Lorentz 6-oscillator dielectric permittivity.
    Reference: Rakić et al., Appl. Opt. 37, 5271 (1998), Table 2.
    """
    omega_p = 9.03 * eV / hbar
    f = np.array([0.760, 0.024, 0.010, 0.071, 0.601, 4.384])
    Gamma = np.array([0.053, 0.241, 0.345, 0.870, 2.494, 2.214]) * eV / hbar
    Omega = np.array([0.000, 0.415, 0.830, 2.969, 4.304, 13.32]) * eV / hbar

    # Drude intraband term
    eps = 1.0 - f[0] * omega_p**2 / (omega * (omega + 1j * Gamma[0]))

    # Lorentz interband oscillators
    for i in range(1, 6):
        eps += f[i] * omega_p**2 / (Omega[i]**2 - omega**2 - 1j * omega * Gamma[i])

    return eps


def eps_Cu_drude(omega):
    """
    Copper (Cu) Drude-Lorentz 5-oscillator dielectric permittivity.
    Reference: Rakić et al., Appl. Opt. 37, 5271 (1998), Table 2.
    """
    omega_p = 10.83 * eV / hbar
    f = np.array([0.575, 0.061, 0.104, 0.723, 0.638])
    Gamma = np.array([0.030, 0.378, 1.056, 3.213, 4.305]) * eV / hbar
    Omega = np.array([0.000, 0.291, 2.957, 5.300, 11.18]) * eV / hbar

    # Drude intraband term
    eps = 1.0 - f[0] * omega_p**2 / (omega * (omega + 1j * Gamma[0]))

    # Lorentz interband oscillators
    for i in range(1, 5):
        eps += f[i] * omega_p**2 / (Omega[i]**2 - omega**2 - 1j * omega * Gamma[i])

    return eps


def validate_causality(eps_array, omega_array=None):
    """
    Check physical passivity condition: Im[eps(omega)] >= 0 for absorbing medium.
    """
    violations = np.sum(np.imag(eps_array) < -1e-6)
    return violations == 0, int(violations)
