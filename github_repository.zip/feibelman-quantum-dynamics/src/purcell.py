"""
purcell.py
==========
Purcell factor calculation routines across distance and photon energy regimes.

Quantities:
  - Perpendicular dipole Purcell enhancement: F_P^perp(z, omega)
  - Parallel dipole Purcell enhancement: F_P^par(z, omega)
  - Orientationally averaged Purcell enhancement: F_P^iso = (1/3)*F_P^perp + (2/3)*F_P^par
  - Relative quantum surface suppression: Delta F_P / F_P^local * 100%
"""

import numpy as np
from .materials import eV_to_omega, eps_Au_drude, eps_Cu_drude
from .feibelman import feibelman_d_perp, feibelman_d_parallel
from .green_tensor import compute_ldos


def compute_purcell_factor(energy_eV, z_m, metal='Au', model='feibelman',
                           u_max=6.0, n_quad=300):
    """Compute Purcell factor at a single energy and distance."""
    omega = eV_to_omega(energy_eV)
    if metal == 'Au':
        eps_m = eps_Au_drude(omega)
    elif metal == 'Cu':
        eps_m = eps_Cu_drude(omega)
    else:
        raise ValueError(f"Unknown metal: {metal}")

    d_perp = feibelman_d_perp(energy_eV) if model == 'feibelman' else None
    d_par  = feibelman_d_parallel(energy_eV) if model == 'feibelman' else None

    return compute_ldos(omega, z_m, eps_m, model=model,
                        d_perp_A=d_perp, d_par_A=d_par,
                        u_max=u_max, n_quad=n_quad)


def purcell_spectrum(energies_eV, z_m, metal='Au', model='feibelman',
                     u_max=6.0, n_quad=300):
    """Compute Purcell factor spectrum over energy array."""
    fp_list = []
    for E in energies_eV:
        res = compute_purcell_factor(E, z_m, metal=metal, model=model,
                                     u_max=u_max, n_quad=n_quad)
        fp_list.append(res['purcell_perp'])
    return np.array(fp_list)


def purcell_distance_sweep(energy_eV, z_array_m, metal='Au', model='feibelman',
                           u_max=6.0, n_quad=300):
    """Compute Purcell factor as a function of emitter-surface distance z."""
    fp_list = []
    for z in z_array_m:
        res = compute_purcell_factor(energy_eV, z, metal=metal, model=model,
                                     u_max=u_max, n_quad=n_quad)
        fp_list.append(res['purcell_perp'])
    return np.array(fp_list)
