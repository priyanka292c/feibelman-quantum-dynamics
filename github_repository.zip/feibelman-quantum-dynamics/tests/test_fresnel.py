"""
test_fresnel.py
===============
Unit tests for Fresnel reflection coefficients across models.
"""

import numpy as np
import pytest
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from src.materials import c0, eV_to_omega, eps_Au_drude
from src.fresnel import kz_medium, rp_local, rs_local, rp_feibelman, rs_feibelman, rp_hydrodynamic


def test_kz_medium_branch():
    """Ensure branch cut choice Im[kz] >= 0 for passivity."""
    omega = eV_to_omega(2.5)
    eps_metal = eps_Au_drude(omega)
    k0 = omega / c0
    
    # Propagating wave in vacuum
    kz_vac = kz_medium(0.5 * k0, omega, 1.0)
    assert np.imag(kz_vac) >= 0.0
    assert np.real(kz_vac) > 0.0

    # Evanescent wave in vacuum
    kz_evan = kz_medium(2.0 * k0, omega, 1.0)
    assert np.imag(kz_evan) >= 0.0

    # Wave in lossy metal
    kz_met = kz_medium(1.0 * k0, omega, eps_metal)
    assert np.imag(kz_met) >= 0.0


def test_feibelman_local_limit():
    """Feibelman reflection coefficient must reduce to local Fresnel when d -> 0."""
    omega = eV_to_omega(2.5)
    eps_metal = eps_Au_drude(omega)
    k0 = omega / c0
    k_pars = np.linspace(0.1, 3.0, 20) * k0

    for kp in k_pars:
        rp_loc = rp_local(kp, omega, 1.0, eps_metal)
        rs_loc = rs_local(kp, omega, 1.0, eps_metal)

        rp_fb_zero = rp_feibelman(kp, omega, eps_metal, d_perp_A=0.0, d_par_A=0.0)
        rs_fb_zero = rs_feibelman(kp, omega, eps_metal, d_perp_A=0.0, d_par_A=0.0)

        np.testing.assert_allclose(rp_fb_zero, rp_loc, rtol=1e-10, atol=1e-12)
        np.testing.assert_allclose(rs_fb_zero, rs_loc, rtol=1e-10, atol=1e-12)


def test_dielectric_energy_conservation():
    """Passive lossless dielectric must satisfy |r|^2 <= 1."""
    omega = eV_to_omega(2.0)
    k0 = omega / c0
    eps_glass = 2.25  # n = 1.5

    # Propagating waves: |r|^2 <= 1
    k_pars = np.linspace(0.0, 0.99, 10) * k0
    for kp in k_pars:
        rp = rp_local(kp, omega, 1.0, eps_glass)
        rs = rs_local(kp, omega, 1.0, eps_glass)
        assert abs(rp)**2 <= 1.0000001
        assert abs(rs)**2 <= 1.0000001


if __name__ == '__main__':
    pytest.main([__file__])
