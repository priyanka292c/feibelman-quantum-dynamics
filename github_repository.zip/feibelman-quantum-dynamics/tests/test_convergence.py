"""
test_convergence.py
===================
Unit tests for numerical convergence of quadrature and distance sampling.
"""

import numpy as np
import pytest
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from src.materials import eV_to_omega, eps_Au_drude
from src.green_tensor import compute_ldos


def test_quadrature_convergence():
    """Verify relative error between N_quad=300 and N_quad=600 is below 0.5% (observed ~0.13%)."""
    omega = eV_to_omega(2.5)
    eps_m = eps_Au_drude(omega)
    z = 5.0e-9

    res_300 = compute_ldos(omega, z, eps_m, model='local', n_quad=300)
    res_600 = compute_ldos(omega, z, eps_m, model='local', n_quad=600)

    rel_diff = abs(res_300['purcell_perp'] - res_600['purcell_perp']) / res_600['purcell_perp']
    assert rel_diff < 0.005, f"Quadrature convergence error too high: {rel_diff:.4e}"


def test_distance_sampling_consistency():
    """Verify interpolation between 0.5 nm steps maintains monotonic decay in the near field."""
    omega = eV_to_omega(2.5)
    eps_m = eps_Au_drude(omega)
    z_steps = np.array([1.0, 1.5, 2.0, 2.5, 3.0]) * 1e-9

    fp_vals = [compute_ldos(omega, z, eps_m, model='local', n_quad=200)['purcell_perp']
               for z in z_steps]

    # Near-field Purcell factor must monotonically decrease with distance
    for i in range(len(fp_vals) - 1):
        assert fp_vals[i] > fp_vals[i+1], f"Non-monotonic behavior at z={z_steps[i]*1e9:.1f} nm"


if __name__ == '__main__':
    pytest.main([__file__])
