"""
test_green_tensor.py
====================
Unit tests for Sommerfeld Green tensor calculations and LDOS.
"""

import numpy as np
import pytest
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from src.materials import eV_to_omega, eps_Au_drude
from src.feibelman import feibelman_d_perp, feibelman_d_parallel
from src.green_tensor import compute_ldos, compute_cross_green_tensor


def test_purcell_enhancement_positivity():
    """Near-field Purcell factor above absorbing metal must exceed 1.0."""
    omega = eV_to_omega(2.5)
    eps_m = eps_Au_drude(omega)
    z = 5.0e-9  # 5 nm

    res_loc = compute_ldos(omega, z, eps_m, model='local', n_quad=200)
    assert res_loc['purcell_perp'] > 1.0
    assert res_loc['ldos_total'] > 1.0

    d_perp = feibelman_d_perp(2.5)
    d_par  = feibelman_d_parallel(2.5)
    res_fb = compute_ldos(omega, z, eps_m, model='feibelman',
                          d_perp_A=d_perp, d_par_A=d_par, n_quad=200)
    assert res_fb['purcell_perp'] > 1.0
    assert res_fb['ldos_total'] > 1.0


def test_cross_green_tensor_symmetry():
    """Reciprocity requires G_zz(r1, r2) = G_zz(r2, r1) when z1 = z2."""
    omega = eV_to_omega(2.5)
    eps_m = eps_Au_drude(omega)
    z1 = 5.0e-9
    z2 = 5.0e-9
    R12 = 15.0e-9

    res12 = compute_cross_green_tensor(omega, z1, z2, R12, eps_m, model='local', n_quad=200)
    res21 = compute_cross_green_tensor(omega, z2, z1, R12, eps_m, model='local', n_quad=200)

    np.testing.assert_allclose(res12['Gamma12'], res21['Gamma12'], rtol=1e-6)
    np.testing.assert_allclose(res12['g12'], res21['g12'], rtol=1e-6)


def test_scattered_field_decay_at_distance():
    """Scattered Green tensor component decays monotonically with increasing emitter height."""
    omega = eV_to_omega(2.5)
    eps_m = eps_Au_drude(omega)
    z_near = 5.0e-9
    z_far  = 20.0e-9
    res_near = compute_ldos(omega, z_near, eps_m, model='local', n_quad=200)
    res_far  = compute_ldos(omega, z_far, eps_m, model='local', n_quad=200)
    assert res_near['purcell_perp'] > res_far['purcell_perp']
    assert res_far['purcell_perp'] > 1.0


if __name__ == '__main__':
    pytest.main([__file__])
