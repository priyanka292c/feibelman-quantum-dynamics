"""
test_kossakowski.py
===================
Unit tests for the Kossakowski decay matrix, complete positivity, and quantum dynamics.
"""

import numpy as np
import pytest
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from src.quantum_dynamics import (
    analyze_kossakowski_matrix,
    solve_exact_kossakowski,
    solve_partitioned
)


def test_kossakowski_positivity_benchmark_rates():
    """Verify positive semidefiniteness across all 4 environments from Table 5."""
    # From manuscript Table 5 (z = 5 nm, R12 = 15 nm above Au at E = 2.5 eV):
    cases = [
        {'name': 'Free Space',   'Gamma1': 1.00,  'Gamma2': 1.00,  'Gamma12': 0.99,  'g12': -107.36},
        {'name': 'Local Model',  'Gamma1': 41.66, 'Gamma2': 41.66, 'Gamma12': 35.67, 'g12': -70.41},
        {'name': 'Hydrodynamic', 'Gamma1': 41.67, 'Gamma2': 41.67, 'Gamma12': 35.67, 'g12': -70.41},
        {'name': 'Feibelman',    'Gamma1': 42.13, 'Gamma2': 42.13, 'Gamma12': 36.04, 'g12': -71.71},
    ]

    for c in cases:
        audit = analyze_kossakowski_matrix(c['Gamma1'], c['Gamma2'], c['Gamma12'])
        assert audit['is_positive_semidefinite'], f"Kossakowski matrix violation in {c['name']}"
        assert audit['lambda_minus'] >= 0.0, f"Negative eigenvalue in {c['name']}"
        assert audit['lambda_plus'] >= audit['lambda_minus']


def test_quantum_dynamics_exact_vs_partitioned():
    """
    Verify exact Kossakowski diagonalization vs heuristic partitioned collapse:
      - Exact Kossakowski yields C_max ~ 0.696, tau_C ~ 0.264
      - Partitioned collapse yields C_max ~ 0.571, tau_C ~ 0.038
    """
    rates_fb = {'Gamma1': 42.13, 'Gamma2': 42.13, 'Gamma12': 36.04, 'g12': -71.71}

    # 1. Exact Kossakowski (Primary Result)
    res_exact = solve_exact_kossakowski(rates_fb, omega_q=10.0, gamma0=1.0, t_max=0.5, n_t=300)
    assert res_exact['validation']['trace_ok']
    assert res_exact['validation']['positive_ok']
    assert 0.68 <= res_exact['c_max'] <= 0.71, f"Unexpected C_max: {res_exact['c_max']}"
    assert 0.24 <= res_exact['tau_C'] <= 0.28, f"Unexpected tau_C: {res_exact['tau_C']}"

    # 2. Partitioned Collapse (Secondary Comparison)
    res_part = solve_partitioned(rates_fb, omega_q=10.0, gamma0=1.0, t_max=0.5, n_t=300)
    assert res_part['validation']['trace_ok']
    assert res_part['validation']['positive_ok']
    assert 0.55 <= res_part['c_max'] <= 0.59, f"Unexpected C_max (part): {res_part['c_max']}"
    assert 0.03 <= res_part['tau_C'] <= 0.05, f"Unexpected tau_C (part): {res_part['tau_C']}"


if __name__ == '__main__':
    pytest.main([__file__])
