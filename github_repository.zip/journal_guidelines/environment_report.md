# Environment Report
**Generated: 2026-10-21**

## Software Detected

| Software | Version | Status | Notes |
|---|---|---|---|
| Python | 3.12.10 | ✅ Detected | Primary analysis language |
| pip | 25.0.1 | ✅ Detected | Package manager |
| numpy | 2.5.1 | ✅ Detected | Numerical computing |
| scipy | 1.18.0 | ✅ Detected | Scientific computing |
| matplotlib | 3.11.0 | ✅ Detected | Plotting |
| pandas | 3.0.3 | ✅ Detected | Data management |
| sympy | 1.14.0 | ✅ Detected | Symbolic math |
| qutip | 5.3.1 | ✅ Installed | Quantum dynamics |
| python-docx | 1.2.0 | ✅ Detected | Word generation |
| requests | 2.34.2 | ✅ Detected | HTTP/DOI verification |
| Git | NOT DETECTED | ❌ Not found | Manual version control |
| MiKTeX pdfLaTeX | 4.23 (MiKTeX 25.12) | ✅ Detected | LaTeX compilation |
| Lumerical FDTD | v241 | ✅ Detected | FDTD simulation |
| lumapi | v241 | ✅ Detected (warning) | Python API available with SyntaxWarning (minor, non-fatal) |
| MATLAB | Not checked | — | Not required for selected direction |
| TD-DFT (GPAW/Octopus) | NOT DETECTED | ❌ Not available | Literature values will be used |
| Docker | Not checked | — | Not required |
| GitHub CLI | Not detected | ❌ | Git not found on PATH |

## Key Notes

### Lumerical FDTD
- Installed at: `C:\Program Files\Lumerical\v241`
- lumapi Python module: available at `C:\Program Files\Lumerical\v241\api\python`
- **STOP CONDITION**: Lumerical license validation required before automation. lumapi will be imported but actual simulation runs require active license. Scripts will be prepared for execution; actual numerical results will come from validated literature-derived datasets where license is not confirmed active.

### TD-DFT
- No GPAW, Octopus, or compatible TD-DFT package detected.
- **Action**: Use validated literature-derived Feibelman d-parameters from:
  - Christensen et al. (2017), *Phys. Rev. Lett.*
  - Toscano et al. (2015), *Nat. Comm.*
  - Raza et al. (2015), *Nanophotonics*
  - Babaze et al. (2022/2023) datasets
- All parameters clearly labeled as "literature-derived."

### Git
- Not found on system PATH.
- Repository structure will be created as a local directory tree.
- ZIP archive will be generated programmatically.

## Python Environment Summary
All required packages for Green tensor computation, quantum dynamics (QuTiP), figure generation, table generation, Word generation, and DOI verification are available.
