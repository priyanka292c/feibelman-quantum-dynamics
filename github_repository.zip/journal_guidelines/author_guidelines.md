# Computational Materials Today — Author Guidelines
**JOURNAL_GUIDELINES_DATE = 2026-10-21**

## Manuscript Structure
Standard Elsevier article structure:
1. Title
2. Authors and Affiliations
3. Abstract (≤ 250 words, unstructured)
4. Keywords (1–7 keywords)
5. Highlights (3–5 bullet points, ≤ 85 characters each including spaces)
6. Graphical Abstract (optional but recommended; 531 × 1328 pixels or proportional)
7. Introduction
8. Methods / Computational Methodology
9. Results and Discussion
10. Conclusions
11. CRediT Author Contribution Statement
12. Declaration of Competing Interests
13. Acknowledgements
14. Data Availability Statement
15. Funding
16. References
17. Supplementary Material (if needed)

## Abstract
- Unstructured
- ≤ 250 words
- Summarize: background, computational methods, main results, conclusions
- No citations in abstract
- No abbreviations unless defined

## Keywords
- 1–7 keywords
- Use specific terms for indexing
- Avoid general terms (e.g., "materials")

## Highlights
- 3–5 bullet points
- Each ≤ 85 characters (including spaces)
- Describe the core findings
- Do NOT use general statements

## References
- Numbered in citation order (Vancouver/numerical style)
- Format: Author(s), Title, Journal, Year, Volume, Pages/Article no., DOI
- DOI must be included where available
- No arXiv-only references in final bibliography

## Figures
- Resolution: minimum 300 DPI for raster images (600 DPI preferred)
- Formats accepted: EPS, PDF, SVG (vector), TIFF, PNG, JPEG
- Each figure on a separate page in submitted manuscript
- Caption below figure
- All panels labeled (a), (b), etc.
- Color: ensure figures are legible in grayscale and color

## Tables
- Numbered sequentially
- Title above table
- Footnotes below
- Editable (not images)

## Declarations Required
1. CRediT Author Contribution Statement
2. Declaration of Competing Interests
3. Data Availability Statement
4. Funding Statement
5. Acknowledgements
6. Generative AI Disclosure (if AI tools used)

## Data/Code Availability
Authors strongly encouraged to deposit code in a public repository (GitHub, Zenodo, etc.) and provide DOI. Include in manuscript.

## Generative AI Policy (Elsevier Standard 2024–2026)
- AI tools may not be listed as authors
- Authors must disclose use of AI in writing/preparation
- Authors retain full responsibility for content accuracy
- Disclosure statement required in manuscript

## Submission System
Elsevier Editorial System (EES) via ScienceDirect/EVISE

## LaTeX
Standard Elsevier `elsarticle` class accepted. Template available via CTAN and Elsevier website.

## Source
Retrieved from: https://www.sciencedirect.com/journal/computational-materials-today/publish/guide-for-authors
Date: 2026-10-21
