# Computational Materials Today — Journal Scope
**JOURNAL_GUIDELINES_DATE = 2026-10-21**

## Publisher
Elsevier (Materials Today family)

## ISSN
2950-3469 (Online, Gold Open Access)

## Aims and Scope
*Computational Materials Today* is a multidisciplinary, gold open-access journal dedicated to publishing cutting-edge research on:

1. New computational methods and tools for materials science
2. Theoretical simulations of materials behavior
3. Innovative design of novel materials using computational approaches

### Fields Covered
- Materials science and engineering
- Physics and Chemistry of materials
- Mathematics, Information Science, and AI-driven materials discovery
- Life sciences (biomaterials)

### Material Classes
- Metals, alloys, ceramics, and composites
- Polymers, soft materials, glasses, and colloidal materials
- **Optical, photonic, optoelectronic, and dielectric materials** ✓ (relevant to our study)
- **Magnetic, quantum, and superconducting materials** ✓ (relevant to our study)
- **Nanomaterials, surface, and low-dimensional materials** ✓ (relevant to our study)
- Energy and catalytic materials
- Biomaterials and strongly correlated materials

## Article Types
- Original Research Articles
- Review Articles
- Short Communications
- Perspectives
- Roadmap Papers

## Open Access
Gold Open Access. APC: USD 3,150 (standard; waivers may apply — verify at submission time).

## Key Relevance to Our Study
The proposed study on quantum surface-response effects (Feibelman d-parameters) integrated with nonlocal electromagnetic Green tensor formalism for nanophotonic systems is directly within scope under:
- Optical/photonic/quantum materials
- Nanomaterials and low-dimensional systems
- Computational method development (multiscale quantum-to-classical framework)
- Novel theoretical simulations

## Source
Retrieved from: https://www.sciencedirect.com/journal/computational-materials-today
Date: 2026-10-21
