# Computational Materials Today — Figure Requirements
**Date: 2026-10-21**

## Resolution & Formats
- Formats: PNG (web/draft), JPEG (photo/raster), PDF/EPS (vector, publication print)
- Resolution: 300–600 DPI for raster figures
- Color mode: RGB / sRGB compliant

## Sizing & Typography
- Widths:
  - Single column: 85–90 mm
  - 1.5 column: 120–140 mm
  - Full width (double column): 170–190 mm
- Font: Serif (Times New Roman / DejaVu Serif) or Sans-Serif (Arial / Helvetica)
- Font size: 8–10 pt at target print size
- Line width: 1.0–2.0 pt for curves, 0.75 pt for axis lines

## Provenance & Integrity
- Every figure must be programmatically generated from reproducible code
- No manual cosmetic retouching of scientific data curves
- Numerical standards: mesh convergence verified (0.5 nm mesh resolution), data points specified (300 points)
- Panels must be clearly labeled (a), (b), (c)...
- All axes must specify variable, units, and clear numerical scale
