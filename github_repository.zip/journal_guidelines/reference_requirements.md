# Computational Materials Today — Reference Requirements
**Date: 2026-10-21**

## Reference Style
- Numbered citation order (`[1]`, `[2]`, `[3]...`)
- Bibliographic entries must appear strictly in order of citation
- Style format: Elsevier standard numerical (`elsarticle-num.bst`)

## Quality & Integrity Mandates
- 100% DOI verification: Every candidate reference must resolve to active Crossref metadata
- Zero fabricated, hallucinated, or duplicate references
- Exclusion of unverified preprints / arXiv-only references
- Traceable source metadata: Author list, title, journal, volume, page numbers, year, and persistent DOI
