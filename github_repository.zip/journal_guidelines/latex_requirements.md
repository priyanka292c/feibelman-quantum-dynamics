# Computational Materials Today — LaTeX Submission Requirements
**Date: 2026-10-21**

## Official Document Class and Structure
- Class: `elsarticle.cls` (official Elsevier LaTeX class)
- Mode: `preprint`, `12pt`, `review`, or standard article format
- Citation management: `elsarticle-num.bst` or `elsarticle-num-names.bst` (numerical citation order)
- Encoding: UTF-8 standard
- Graphics: `graphicx` package with PDF/PNG/JPEG vector/raster formats
- Math: `amsmath`, `amssymb`, `bm`, `physics` packages

## Formatting Rules
- Title: Concise and informative
- Abstract: Single paragraph, 150–250 words
- Keywords: 4–6 keywords for indexing
- Mathematics: Numbered equations using standard `equation` environment
- Tables: Professional format with `booktabs` (`\toprule`, `\midrule`, `\bottomrule`)
- Cross-referencing: Standard `\label` and `\ref` or `\Cref`
- Compiler target: pdfLaTeX with BibTeX
