# Computational Materials Today — Submission Package Checklist
**Date: 2026-10-21**

| Item | Requirement | Status | Notes |
|---|---|---|---|
| Manuscript File | LaTeX (`main.tex`) & Word (`.docx`) | Verified | Fully synchronized |
| PDF Output | pdfLaTeX compiled with zero errors | Verified | Clean compilation |
| Graphical Abstract | Concept to application flow | Verified | Included in manuscript |
| Highlights | 3–5 bullet points (max 85 char each) | Verified | Included in front matter |
| Author Contributions | CRediT formal classification | Verified | Defined in front matter & text |
| Declarations | Competing interests, Funding, AI use | Verified | Explicit statements included |
| Figures | High resolution PNG, JPEG, PDF | Verified | 11 publication figures |
| Figure Provenance | Script-to-data-to-figure traceability | Verified | `figure_provenance.csv` |
| Numerical Standards | Mesh size 0.5 nm, Data points 300 | Verified | Explicitly demonstrated |
| References | 100% DOI-verified against Crossref | Verified | `references_verified.bib` |
| Code & Data | Reproducibility scripts & raw datasets | Verified | Full `/reproduce/` pipeline |
